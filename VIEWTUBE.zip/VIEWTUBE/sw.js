/* =====================================================================
   VIEWTUBE · sw.js (service worker)
   - Faz cache do "app shell" (arquivos do aplicativo) e abre offline.
   - Para publicar uma versão nova: aumente o número em CACHE_VERSION.
   - Vídeos e músicas do usuário NÃO passam por aqui: ficam no IndexedDB
     (são lidos via blob:, que o service worker nem enxerga).
   ===================================================================== */
'use strict';

const CACHE_VERSION = 4;                       // <- aumente a cada atualização (1, 2, 3...)
const CACHE_PREFIX = 'viewtube-';
const CACHE_NAME = CACHE_PREFIX + 'v' + CACHE_VERSION;

// Sem estes o app não abre offline: se algum falhar, a instalação do SW falha e tenta de novo depois.
const CORE_ASSETS = [
  './',
  './index.html',
  './style.css',
  './script.js',
  './manifest.json',
  './imagens/logo.png',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/icon-512-maskable.png'
];
// Importante para a tela de carregamento, mas grande: se falhar, o app continua funcionando.
const OPTIONAL_ASSETS = ['./imagens/banner.png'];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(CORE_ASSETS.map(url => new Request(url, { cache: 'reload' })));
    await Promise.all(OPTIONAL_ASSETS.map(url =>
      cache.add(new Request(url, { cache: 'reload' })).catch(err => console.warn('[SW] Item opcional não colocado em cache:', url, err))));
    // Não chamamos skipWaiting() aqui: a versão nova espera o usuário clicar em "Atualizar".
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(n => n.startsWith(CACHE_PREFIX) && n !== CACHE_NAME).map(n => caches.delete(n)));
    await self.clients.claim();
  })());
});

// O botão "Atualizar" da página envia esta mensagem para ativar a versão nova.
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;                          // nada de terceiros
  if (req.headers.has('range') || req.destination === 'video' || req.destination === 'audio') return; // mídia nunca vai para o cache

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    // 1) Cache primeiro (ignora ?query, ex.: index.html?x=1)
    const hit = await cache.match(req, { ignoreSearch: true });
    if (hit) return hit;
    // 2) Rede; se estiver offline numa navegação, devolve o index.html em cache
    try {
      const res = await fetch(req);
      return res;
    } catch (err) {
      if (req.mode === 'navigate') {
        const fallback = await cache.match('./index.html');
        if (fallback) return fallback;
      }
      return new Response('Sem conexão.', { status: 503, statusText: 'Offline', headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
    }
  })());
});
