'use strict';
/* =====================================================================
   VIEWTUBE · script.js
   Seções: 1 Utilidades · 2 Configurações · 3 IndexedDB · 4 Mídia/Upload
           5 Renderização · 6 Navegação · 7 Vídeo · 8 Música · 9 Playlists
           10 Ações · 11 Pesquisa · 12 Downloads · 13 Interface · 14 Início
   ===================================================================== */

/* ---------- 1. Utilidades e estado ---------- */
const DB_NAME = 'viewtube-local-db', DB_VERSION = 1;
const STORES = ['items', 'playlists', 'history', 'later', 'favorites'];
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const CATEGORIES = ['Geral', 'Música', 'Filme', 'Educação', 'Tutorial', 'Podcast', 'Games', 'Outros'];
const ACCENTS = { '#8B00FF': '#D000FF', '#A000FF': '#E040FF', '#6A00F4': '#B517FF', '#C400FF': '#FF2BD6' };
const DEFAULTS = { theme: 'dark', accent: '#8B00FF', reduceMotion: false, vAutoplay: true, vSpeed: 1,
  mAutoplay: true, mVolume: 0.8, mRepeat: 'off', mShuffle: false };
const EXT_MIME = { mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm', ogv: 'video/ogg', mov: 'video/quicktime',
  mkv: 'video/x-matroska', mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/ogg',
  m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', weba: 'audio/webm' };

const S = { items: [], playlists: [], history: [], later: [], favorites: [], downloads: [],
  page: 'home', chip: 'all', watchId: null, vqueue: [], playlistId: null, watchPl: null, vloop: false,
  view: { videos: { q: '', sort: 'new' }, music: { q: '', sort: 'new' }, library: { q: '', sort: 'new' } },
  search: { q: '', type: 'all', sort: 'new' },
  queue: [], qi: -1, back: [], played: new Set(), curAudio: null, shuffle: false, repeat: 'off' };
let db = null, cfg = { ...DEFAULTS }, uiBound = false;
const urlCache = new Map();

const esc = (s = '') => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
const ic = n => `<svg class="i"><use href="#i-${n}"/></svg>`;
const getItem = id => S.items.find(i => i.id === id);
const inList = (l, id) => l.some(x => x.id === id);
const fmtTime = s => { if (!Number.isFinite(s) || s < 0) return '0:00'; s = Math.floor(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s % 60).padStart(2, '0'); };
const fmtSize = n => { if (!n) return '—'; const u = ['B', 'KB', 'MB', 'GB']; let i = 0; while (n >= 1024 && i < 3) { n /= 1024; i++; } return n.toFixed(i ? 1 : 0) + ' ' + u[i]; };
const fmtDate = t => new Date(t).toLocaleDateString('pt-BR');
const fmtDateTime = t => new Date(t).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const setP = (el, pct) => el.style.setProperty('--p', pct + '%');

let toastTimer;
function notify(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 3200); }
function errMsg(e) { if (e && (e.name === 'QuotaExceededError' || /quota/i.test(e.message || ''))) return 'Sem espaço de armazenamento no navegador. Exclua conteúdos e tente de novo.'; return (e && e.message) || 'Algo deu errado.'; }
const urlFor = it => { if (!urlCache.has(it.id)) urlCache.set(it.id, URL.createObjectURL(it.blob)); return urlCache.get(it.id); };
function revokeUrl(id) { if (urlCache.has(id)) { URL.revokeObjectURL(urlCache.get(id)); urlCache.delete(id); } }

/* ---------- 2. Configurações (LocalStorage) ---------- */
function loadSettings() {
  let s = {}; try { s = JSON.parse(localStorage.getItem('vt-settings') || '{}') || {}; } catch (e) { s = {}; }
  const t = localStorage.getItem('vt-theme'), sp = parseFloat(localStorage.getItem('vt-speed')); // migra chaves da versão anterior
  if (t && s.theme === undefined) s.theme = t;
  if (sp && s.vSpeed === undefined) s.vSpeed = sp;
  cfg = { ...DEFAULTS, ...s };
  S.shuffle = !!cfg.mShuffle; S.repeat = cfg.mRepeat;
  applyTheme();
}
function saveSettings() { try { localStorage.setItem('vt-settings', JSON.stringify(cfg)); } catch (e) { /* armazenamento indisponível */ } }
function applyTheme() {
  document.body.classList.toggle('light', cfg.theme === 'light');
  document.body.classList.toggle('reduce-motion', !!cfg.reduceMotion);
  const r = document.documentElement.style; r.setProperty('--accent', cfg.accent); r.setProperty('--accent2', ACCENTS[cfg.accent] || '#D000FF');
  const m = $('meta[name=theme-color]'); if (m) m.content = cfg.theme === 'light' ? '#f4f0f8' : '#08060D';
}
function loadDownloadsLog() { try { S.downloads = JSON.parse(localStorage.getItem('vt-downloads') || '[]') || []; } catch (e) { S.downloads = []; } }
const saveDownloadsLog = () => { try { localStorage.setItem('vt-downloads', JSON.stringify(S.downloads)); } catch (e) { /* ignore */ } };

/* ---------- 3. IndexedDB ---------- */
function openDB() {
  return new Promise((res, rej) => {
    if (!('indexedDB' in window)) return rej(new Error('Este navegador não oferece IndexedDB, necessário para guardar sua biblioteca.'));
    let req; try { req = indexedDB.open(DB_NAME, DB_VERSION); } catch (e) { return rej(new Error('O armazenamento local está bloqueado (modo privado ou permissões).')); }
    const timer = setTimeout(() => rej(new Error('O armazenamento demorou demais para responder.')), 8000);
    req.onupgradeneeded = () => { const d = req.result; STORES.forEach(n => { if (!d.objectStoreNames.contains(n)) d.createObjectStore(n, { keyPath: 'id' }); }); };
    req.onsuccess = () => { clearTimeout(timer); db = req.result; db.onversionchange = () => db.close(); res(); };
    req.onerror = () => { clearTimeout(timer); rej(req.error || new Error('Falha ao abrir o armazenamento local.')); };
    req.onblocked = () => { clearTimeout(timer); rej(new Error('Feche outras abas do VIEWTUBE e tente novamente.')); };
  });
}
const dbAll = n => new Promise((res, rej) => { const r = db.transaction(n).objectStore(n).getAll(); r.onsuccess = () => res(r.result || []); r.onerror = () => rej(r.error); });
const dbWrite = (n, fn) => new Promise((res, rej) => { const tx = db.transaction(n, 'readwrite'); fn(tx.objectStore(n)); tx.oncomplete = () => res(); tx.onabort = tx.onerror = () => rej(tx.error || new Error('Falha ao gravar os dados.')); });
const dbPut = (n, o) => dbWrite(n, s => s.put(o));
const dbDel = (n, id) => dbWrite(n, s => s.delete(id));
const dbClear = n => dbWrite(n, s => s.clear());
const quiet = p => p.catch(e => console.warn('VIEWTUBE:', e));

/* ---------- 4. Mídia: validação, metadados, upload ---------- */
const mimeOf = f => (f.type && /^(video|audio)\//.test(f.type)) ? f.type : (EXT_MIME[(f.name.split('.').pop() || '').toLowerCase()] || '');
const typeOf = f => { const m = mimeOf(f); return m.startsWith('video/') ? 'video' : m.startsWith('audio/') ? 'audio' : null; };

/* Lê duração e, para vídeos, gera miniatura. Rejeita se o navegador não consegue reproduzir. */
function probeMedia(file, type) {
  return new Promise((res, rej) => {
    const el = document.createElement(type === 'video' ? 'video' : 'audio'); el.preload = 'metadata'; el.muted = true; el.playsInline = true;
    const u = URL.createObjectURL(file); let done = false, duration = 0;
    const fin = (fn, v) => { if (done) return; done = true; clearTimeout(t); el.removeAttribute('src'); el.load(); URL.revokeObjectURL(u); fn(v); };
    const t = setTimeout(() => fin(rej, new Error('Não foi possível ler este arquivo (tempo esgotado).')), 12000);
    el.onerror = () => fin(rej, new Error('O navegador não consegue reproduzir este formato. Tente MP4 (H.264), WebM, MP3, WAV ou OGG.'));
    el.onloadedmetadata = () => { duration = el.duration; if (type === 'audio' || !el.videoWidth) return fin(res, { duration }); el.currentTime = Math.min(1, (duration || 2) / 2); };
    el.onseeked = () => { let thumb = null; try { const w = 480, h = Math.round(w * el.videoHeight / el.videoWidth), c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(el, 0, 0, w, h); thumb = c.toDataURL('image/jpeg', 0.72); } catch (e) { /* sem miniatura */ } fin(res, { duration, thumb }); };
    el.src = u;
  });
}
function imageToDataURL(file, max = 640) {
  return new Promise((res, rej) => {
    if (!file.type.startsWith('image/')) return rej(new Error('A capa precisa ser uma imagem.'));
    const u = URL.createObjectURL(file), img = new Image();
    img.onload = () => { const k = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL('image/jpeg', 0.8)); };
    img.onerror = () => { URL.revokeObjectURL(u); rej(new Error('Não foi possível ler a imagem de capa.')); };
    img.src = u;
  });
}
async function createItem(file, type, meta, f) {
  const mime = mimeOf(file); const item = { id: uid(), type, title: f.title, artist: f.artist || '', category: f.category || 'Geral', description: f.description || '',
    name: file.name, mime, size: file.size, added: Date.now(), duration: meta.duration || 0, thumb: meta.thumb || null, cover: f.cover || null,
    blob: file.type === mime ? file : file.slice(0, file.size, mime) };
  await dbPut('items', item); S.items.push(item); return item;
}
async function persistStorage() { try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (e) { /* opcional */ } }

const U = { file: null, type: null, url: null, busy: false };
function openUpload() { resetUpload(); openModal('uploadModal'); }
function resetUpload() {
  if (U.url) URL.revokeObjectURL(U.url); Object.assign(U, { file: null, type: null, url: null, busy: false });
  ['fileInput', 'multiInput', 'folderInput', 'coverInput'].forEach(i => $('#' + i).value = '');
  ['contentTitle', 'contentArtist', 'contentDescription'].forEach(i => $('#' + i).value = '');
  $('#contentCategory').innerHTML = CATEGORIES.map(c => `<option>${c}</option>`).join('');
  $('#uploadPreview').hidden = true; $('#uploadPreview').innerHTML = ''; $('#upBusy').hidden = true;
  $('#fileMeta').textContent = 'Os arquivos ficam salvos apenas neste navegador; nada é enviado para a internet.';
  $('#saveUpload').disabled = false; $('#saveUpload').textContent = 'Importar conteúdo'; $('#upProg').hidden = true; $('#coverName').textContent = 'Nenhuma';
}
function closeUpload() { if (U.busy) return notify('Aguarde o processamento terminar.'); resetUpload(); closeModal('uploadModal'); }
function onFilePicked(f) {
  if (!f) return;
  const type = typeOf(f); if (!type) { $('#fileInput').value = ''; return notify('Formato incompatível. Escolha um arquivo de vídeo ou áudio.'); }
  if (U.url) URL.revokeObjectURL(U.url);
  U.file = f; U.type = type; U.url = URL.createObjectURL(f);
  if (!$('#contentTitle').value) $('#contentTitle').value = f.name.replace(/\.[^.]+$/, '');
  if (type === 'audio') $('#contentCategory').value = 'Música';
  const hint = document.createElement(type === 'video' ? 'video' : 'audio').canPlayType(mimeOf(f)) ? '' : ' · ⚠ o navegador pode não reproduzir este formato';
  $('#fileMeta').textContent = `${type === 'video' ? 'Vídeo' : 'Música'} · ${f.name} · ${fmtSize(f.size)} · ${mimeOf(f)}${hint}`;
  const p = $('#uploadPreview'); p.hidden = false; p.innerHTML = type === 'video' ? '<video controls playsinline preload="metadata"></video>' : '<audio controls preload="metadata"></audio>';
  const m = p.firstChild; m.onerror = () => { $('#fileMeta').textContent = '⚠ Este arquivo não pode ser reproduzido pelo navegador.'; $('#saveUpload').disabled = true; };
  $('#saveUpload').disabled = false; m.src = U.url;
}
async function saveUpload() {
  if (U.busy) return;
  if (!U.file) return notify('Selecione um arquivo primeiro.');
  const title = $('#contentTitle').value.trim(); if (!title) { $('#contentTitle').focus(); return notify('Informe um título.'); }
  U.busy = true; $('#saveUpload').disabled = true; $('#saveUpload').textContent = 'Processando...'; $('#upBusy').hidden = false;
  try {
    const meta = await probeMedia(U.file, U.type);
    const cf = $('#coverInput').files[0]; const cover = cf ? await imageToDataURL(cf) : null;
    await createItem(U.file, U.type, meta, { title, artist: $('#contentArtist').value.trim(), category: $('#contentCategory').value, description: $('#contentDescription').value.trim(), cover });
    U.busy = false; resetUpload(); closeModal('uploadModal'); persistStorage(); render(); notify('Conteúdo importado para sua biblioteca!');
  } catch (e) { U.busy = false; $('#upBusy').hidden = true; $('#saveUpload').disabled = false; $('#saveUpload').textContent = 'Importar conteúdo'; notify(errMsg(e)); }
}
/* Importação em lote (vários arquivos ou uma pasta inteira) */
async function importMany(files) {
  files = [...files]; const list = files.filter(f => typeOf(f)), skipped = files.length - list.length;
  if (!list.length) return notify('Nenhum vídeo ou áudio compatível foi encontrado.');
  if (!$('#uploadModal').classList.contains('show')) openUpload();
  U.busy = true; $('#upBusy').hidden = false; $('#saveUpload').disabled = true; const pg = $('#upProg'); pg.hidden = false; pg.max = list.length; pg.value = 0; let ok = 0, fail = 0;
  for (let i = 0; i < list.length; i++) {
    $('#upBusyText').textContent = `Importando ${i + 1} de ${list.length}: ${list[i].name}`;
    try { const type = typeOf(list[i]), meta = await probeMedia(list[i], type); await createItem(list[i], type, meta, { title: list[i].name.replace(/\.[^.]+$/, ''), category: type === 'audio' ? 'Música' : 'Geral' }); ok++; }
    catch (e) { fail++; if (/espaço/.test(errMsg(e))) { notify(errMsg(e)); break; } }
    pg.value = i + 1;
  }
  U.busy = false; resetUpload(); closeModal('uploadModal'); persistStorage(); render(); notify(`${ok} importado(s)` + (fail ? `, ${fail} com falha` : '') + (skipped ? `, ${skipped} ignorado(s) por formato` : '') + '.');
}

/* ---------- 5. Renderização ---------- */
function sortItems(list, mode) { const l = [...list]; if (mode === 'old') l.sort((a, b) => a.added - b.added); else if (mode === 'az') l.sort((a, b) => a.title.localeCompare(b.title, 'pt-BR', { sensitivity: 'base' })); else l.sort((a, b) => b.added - a.added); return l; }
const matches = (it, q) => !q || [it.title, it.artist, it.category, it.description].join(' ').toLowerCase().includes(q.toLowerCase());
const histOf = id => S.history.find(h => h.id === id);
function progBar(it) { const h = histOf(it.id); const d = it.duration || (h && h.duration); return h && h.progress > 0 && d ? `<i class="prog" style="width:${Math.min(100, h.progress / d * 100).toFixed(1)}%"></i>` : ''; }
function thumbHTML(it) {
  const img = it.cover || it.thumb;
  return `<div class="thumb${img || it.type !== 'video' || it.noThumb ? '' : ' shimmer'}">${img ? `<img src="${img}" alt="" loading="lazy">` : `<span class="ph">${ic(it.type === 'video' ? 'video' : 'music')}</span>`}<span class="play">${ic('play')}</span><span class="badge">${it.duration ? fmtTime(it.duration) : (it.type === 'video' ? 'VÍDEO' : 'ÁUDIO')}</span>${progBar(it)}</div>`;
}
const ibtn = (act, id, icon, label, on) => `<button class="ib${on ? ' on' : ''}" data-act="${act}" data-id="${id}" title="${label}" aria-label="${label}">${ic(icon)}</button>`;
const tbtn = (act, id, icon, label, on, extra = '') => `<button class="btn${on ? ' on' : ''}" data-act="${act}" data-id="${id}" ${extra}>${ic(icon)}<span>${label}</span></button>`;
const hue = t => { let h = 0; for (const c of t) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const avatarHTML = it => { const n = (it.artist || it.title || '?').trim(); return it.cover ? `<img class="av" src="${it.cover}" alt="">` : `<span class="av" style="background:hsl(${hue(n)} 60% 40%)" aria-hidden="true">${esc((n[0] || '?').toUpperCase())}</span>`; };
const ago = t => { const d = (Date.now() - t) / 864e5, pl = (n, a, b) => n + ' ' + (n === 1 ? a : b);
  if (d < 1 / 24) return 'agora'; if (d < 1) return 'há ' + Math.floor(d * 24) + ' h'; if (d < 30) return 'há ' + pl(Math.floor(d), 'dia', 'dias');
  if (d < 365) return 'há ' + pl(Math.floor(d / 30), 'mês', 'meses'); return 'há ' + pl(Math.floor(d / 365), 'ano', 'anos'); };
function cardHTML(it) {
  const sub = [it.artist || it.category || 'Minha biblioteca', fmtSize(it.size), ago(it.added)].join(' · ');
  return `<article class="card" tabindex="0" data-id="${it.id}" data-type="${it.type}">${thumbHTML(it)}<div class="cmeta">${avatarHTML(it)}<div class="cinfo"><h3>${esc(it.title)}</h3><p>${esc(sub)}</p></div>${ibtn('more', it.id, 'more', 'Mais opções').replace('class="ib', 'class="ib more')}</div></article>`;
}
const sqHTML = it => `<div class="sq" tabindex="0" data-id="${it.id}" data-type="${it.type}">${thumbHTML(it)}<h3>${esc(it.title)}</h3><p>${esc(it.artist || it.category || '')}</p></div>`;
const sqPl = p => { const f = p.ids.map(getItem).find(Boolean), img = f && (f.cover || f.thumb); return `<div class="sq" tabindex="0" data-pl="${p.id}"><div class="thumb">${img ? `<img src="${img}" alt="" loading="lazy">` : `<span class="ph">${ic('list')}</span>`}<span class="badge">${p.ids.length}</span></div><h3>${esc(p.name)}</h3><p>Playlist</p></div>`; };
const shelf = (title, list, goto, fn = sqHTML) => list.length ? `<div class="section-head"><h2>${title}</h2><button class="btn small" data-goto="${goto}">Ver tudo</button></div><div class="shelf">${list.map(fn).join('')}</div>` : '';
function rowHTML(it, { sub = '', extra = '', actions = '', num = '', cls = '' } = {}) {
  return `<div class="row ${cls}" tabindex="0" data-id="${it.id}" data-type="${it.type}">${num ? `<span class="rnum">${num}</span>` : ''}<div class="rthumb">${thumbHTML(it)}</div><div class="rinfo"><h3>${esc(it.title)}</h3><p>${sub || esc(it.artist || it.category || '')}</p>${extra}</div><div class="ractions">${actions}</div></div>`;
}
function emptyHTML(msg, showAdd = true, title = 'Nada por aqui ainda') {
  return `<div class="empty"><img class="logo-img" src="imagens/logo.png" alt=""><h3>${title}</h3><p>${msg}</p>${showAdd ? `<div class="btnrow"><button class="btn primary" data-act="upload">${ic('plus')} Adicionar conteúdo</button></div>` : ''}</div>`;
}
function fillGrid(id, list, emptyMsg, showAdd = true) { const el = $('#' + id); el.innerHTML = list.length ? list.map(cardHTML).join('') : emptyHTML(emptyMsg, showAdd); }
function playlistCard(p) {
  const first = p.ids.map(getItem).find(Boolean), img = first && (first.cover || first.thumb);
  return `<article class="card" tabindex="0" data-pl="${p.id}"><div class="thumb">${img ? `<img src="${img}" alt="">` : `<span class="ph">${ic('list')}</span>`}<span class="play">${ic('play')}</span><span class="badge">${p.ids.length} ${p.ids.length === 1 ? 'item' : 'itens'}</span></div>
  <div class="card-info"><h3>${esc(p.name)}</h3><p>${esc(p.description || 'Playlist')}</p><div class="card-actions">${ibtn('plplay', p.id, 'play', 'Reproduzir playlist')}${ibtn('pledit', p.id, 'edit', 'Editar playlist')}${ibtn('pldel', p.id, 'trash', 'Excluir playlist')}</div></div></article>`;
}
const group = (title, html) => `<div class="section-head"><h2>${title}</h2></div>${html}`;
const viewList = (name, type) => sortItems(S.items.filter(i => (!type || i.type === type) && matches(i, S.view[name].q)), S.view[name].sort);

const R = {
  home() {
    const el = $('#homeContent'), ck = S.chip || 'all';
    $('#chipbar').innerHTML = [['all', 'Tudo'], ['video', 'Vídeos'], ['audio', 'Músicas'], ['recent', 'Recentes'], ['fav', 'Favoritos'], ...CATEGORIES.map(c => [c, c])]
      .map(([k, l]) => `<button class="chip${k === ck ? ' active' : ''}" data-chip="${k}">${l}</button>`).join('');
    if (!S.items.length) { el.innerHTML = `<div class="grid">${emptyHTML('Adicione seus primeiros vídeos e músicas para montar sua central multimídia. Tudo fica guardado neste navegador.', true, 'Sua biblioteca está vazia')}</div>`; return; }
    const rec = sortItems(S.items, 'new');
    if (ck === 'all') {
      const vids = rec.filter(i => i.type === 'video'), mus = rec.filter(i => i.type === 'audio'), g = l => l.length ? `<div class="grid">${l.map(cardHTML).join('')}</div>` : '';
      const cw = continueList(); el.innerHTML = shelf('Continuar assistindo', cw, 'history', cwHTML) + recShelf() + g(vids.slice(0, 3)) + shelf('Músicas', mus.slice(0, 12), 'music') + g(vids.slice(3)) + shelf('Playlists', S.playlists.slice(0, 10), 'playlists', sqPl);
      return;
    }
    const list = ck === 'video' || ck === 'audio' ? rec.filter(i => i.type === ck) : ck === 'recent' ? rec.slice(0, 20) : ck === 'fav' ? rec.filter(i => inList(S.favorites, i.id)) : rec.filter(i => i.category === ck);
    el.innerHTML = list.length ? `<div class="grid">${list.map(cardHTML).join('')}</div>` : `<div class="grid">${emptyHTML('Nada neste filtro por enquanto.', false, 'Nenhum conteúdo')}</div>`;
  },
  you() {
    const g = l => l.map(x => getItem(x.id)).filter(Boolean).slice(0, 12);
    const html = shelf('Histórico', g(S.history), 'history') + shelf('Assistir mais tarde', g(S.later), 'later') + shelf('Playlists', S.playlists.slice(0, 12), 'playlists', sqPl) + shelf('Favoritos', g(S.favorites), 'favorites') + shelf('Downloads', g(S.downloads), 'downloads');
    $('#youContent').innerHTML = (html || emptyHTML('Seu histórico, favoritos e playlists aparecem aqui.', false, 'Nada por aqui ainda')) + `<div class="menulist"><button data-goto="library">${ic('folder')}<span>Minha biblioteca</span></button><button data-goto="settings">${ic('gear')}<span>Configurações</span></button></div>`;
  },
  videos() { fillGrid('videoGrid', viewList('videos', 'video'), S.view.videos.q ? 'Nenhum vídeo encontrado.' : 'Importe vídeos para vê-los aqui.'); },
  music() { fillGrid('musicGrid', viewList('music', 'audio'), S.view.music.q ? 'Nenhuma música encontrada.' : 'Importe músicas para ouvi-las aqui.'); },
  library() { fillGrid('libraryGrid', viewList('library'), S.view.library.q ? 'Nada encontrado na biblioteca.' : 'Sua biblioteca está vazia.'); },
  later() { fillGrid('laterGrid', S.later.map(x => getItem(x.id)).filter(Boolean), 'Use o ícone de relógio em qualquer conteúdo para guardá-lo aqui.', false); },
  favorites() { fillGrid('favoriteGrid', S.favorites.map(x => getItem(x.id)).filter(Boolean), 'Toque no coração de um conteúdo para favoritá-lo.', false); },
  playlists() { $('#playlistGrid').innerHTML = S.playlists.length ? S.playlists.map(playlistCard).join('') : emptyHTML('Crie playlists para organizar vídeos e músicas.', false, 'Nenhuma playlist'); },
  history() {
    const rows = S.history.map(h => ({ h, it: getItem(h.id) })).filter(x => x.it), el = $('#historyList');
    if (!rows.length) { el.innerHTML = `<div class="grid">${emptyHTML('O que você reproduzir aparecerá aqui.', false, 'Histórico vazio')}</div>`; return; }
    const groups = {}; rows.forEach(({ h, it }) => { const d = new Date(h.date), today = new Date(), y = new Date(Date.now() - 864e5);
      const key = d.toDateString() === today.toDateString() ? 'Hoje' : d.toDateString() === y.toDateString() ? 'Ontem' : fmtDate(h.date); (groups[key] = groups[key] || []).push({ h, it }); });
    el.innerHTML = Object.entries(groups).map(([k, l]) => `<div class="group-title">${k}</div><div class="list">${l.map(({ h, it }) => {
      const d = it.duration || h.duration, canResume = h.progress > 5 && (!d || h.progress < d - 5);
      return rowHTML(it, { sub: `${it.type === 'video' ? 'Vídeo' : 'Música'} · ${fmtDateTime(h.date)}`, extra: canResume ? `<p>Parou em ${fmtTime(h.progress)}${d ? ' de ' + fmtTime(d) : ''}</p>` : '',
        actions: (canResume ? tbtn('resume', it.id, 'play', 'Retomar', false) : '') + ibtn('rmhist', it.id, 'close', 'Remover do histórico') }); }).join('')}</div>`).join('');
  },
  playlist() {
    const p = S.playlists.find(x => x.id === S.playlistId), el = $('#playlistDetail');
    if (!p) { el.innerHTML = emptyHTML('Esta playlist não existe mais.', false, 'Playlist não encontrada'); return; }
    p.ids = p.ids.filter(id => getItem(id));
    const items = p.ids.map(getItem), first = items[0], img = first && (first.cover || first.thumb);
    const nv = items.filter(i => i.type === 'video').length, nm = items.length - nv, dur = items.reduce((t, i) => t + (i.duration || 0), 0);
    const meta = [nv ? `${nv} ${nv === 1 ? 'vídeo' : 'vídeos'}` : '', nm ? `${nm} ${nm === 1 ? 'música' : 'músicas'}` : '', dur ? fmtTime(dur) : '', 'Atualizada ' + ago(p.updated || p.created || Date.now())].filter(Boolean).join(' · ');
    el.innerHTML = `<div class="pl-head ypl"><div class="pl-cover"><div class="thumb">${img ? `<img src="${img}" alt="">` : `<span class="ph">${ic('list')}</span>`}</div></div><div class="ypl-info"><h1 class="page-title">${esc(p.name)}</h1><p class="sub">${meta}</p>${p.description ? `<p class="sub ypl-desc">${esc(p.description)}</p>` : ''}
      <div class="btnrow ypl-btns">${tbtn('plplay', p.id, 'play', 'Reproduzir', false, 'style="background:var(--accent-grad);border:0;color:#fff"')}${tbtn('plshufplay', p.id, 'shuffle', 'Aleatório')}${ibtn('pladd', p.id, 'plus', 'Adicionar conteúdos')}${ibtn('pledit', p.id, 'edit', 'Editar playlist')}${ibtn('pldel', p.id, 'trash', 'Excluir playlist')}<button class="ib" data-goto="playlists" aria-label="Todas as playlists">${ic('back')}</button></div></div></div>
      <div class="list">${items.length ? items.map((it, i) => rowHTML(it, { cls: 'plrow', num: i + 1, sub: `${it.type === 'video' ? 'Vídeo' : 'Música'} · ${esc(it.artist || it.category)}`,
        actions: (i > 0 ? ibtn('plup', it.id, 'up', 'Mover para cima') : '') + (i < items.length - 1 ? ibtn('pldown', it.id, 'down', 'Mover para baixo') : '') + ibtn('plrm', it.id, 'close', 'Remover da playlist') })).join('') : emptyHTML('Use “Adicionar conteúdos” para montar esta playlist.', false, 'Playlist vazia')}</div>`;
  },
  search() { rSearch(); },
  downloads() { rDownloads(); },
  settings() { refreshStorage(); },
  link() { $('#linkMsg').textContent = ''; $('#linkProg').hidden = true; },
  watch() { updateWatchInfo(); }
};
function render() { (R[S.page] || (() => {}))(); }

/* ---------- 6. Navegação ---------- */
function navigate(page) {
  if (S.page === 'watch' && page !== 'watch') stopVideo();
  S.page = page;
  $$('.page').forEach(p => p.classList.toggle('active', p.id === 'page-' + page));
  const navKey = page === 'playlist' ? 'playlists' : page;
  $$('#nav button').forEach(b => b.classList.toggle('active', b.dataset.page === navKey));
  document.body.classList.remove('side-open'); if (page !== 'watch') document.body.classList.remove('cinema');
  const hub = ['you', 'history', 'later', 'favorites', 'playlists', 'playlist', 'downloads', 'library', 'link', 'settings'], bn = ['home', 'videos', 'music'].includes(page) ? page : hub.includes(page) ? 'you' : null;
  $$('#bottomnav [data-page]').forEach(b => b.classList.toggle('active', b.dataset.page === bn)); document.body.classList.toggle('watching', page === 'watch'); document.body.classList.remove('tb-hide');
  render(); window.scrollTo(0, 0);
}

/* ---------- 7. Vídeo ---------- */
function continueList() { return S.history.map(h => ({ h, it: getItem(h.id) })).filter(({ h, it }) => it && it.type === 'video' && h.progress > 5 && (it.duration || h.duration) && h.progress < (it.duration || h.duration) - 10).slice(0, 12).map(x => x.it); }
const cwHTML = it => `<div class="sq" tabindex="0" data-id="${it.id}" data-type="video">${thumbHTML(it)}<h3>${esc(it.title)}</h3><p>Parou em ${fmtTime(histOf(it.id).progress)}</p></div>`;
/* Recomendações locais: pontua por categoria/artista de favoritos e histórico, evita itens vistos hoje e repetições recentes */
function recShelf() {
  if (S.items.length < 4) return '';
  const w = {}, add = (k, n) => { if (k) w[k] = (w[k] || 0) + n; };
  S.history.slice(0, 40).forEach(h => { const it = getItem(h.id); if (it) { add('c:' + it.category, 1); add('a:' + it.artist, 2); } });
  S.favorites.forEach(f => { const it = getItem(f.id); if (it) { add('c:' + it.category, 3); add('a:' + it.artist, 4); } });
  const recent = new Set(S.history.slice(0, 6).map(h => h.id)), shown = (() => { try { return JSON.parse(sessionStorage.getItem('vt-rec') || '[]'); } catch (e) { return []; } })();
  const list = S.items.filter(i => !recent.has(i.id) && !inList(S.favorites, i.id)).map(i => ({ i, sc: (w['c:' + i.category] || 0) + (w['a:' + i.artist] || 0) + (shown.includes(i.id) ? -5 : 0) + Math.random() * 2 })).sort((a, b) => b.sc - a.sc).slice(0, 10).map(x => x.i);
  try { sessionStorage.setItem('vt-rec', JSON.stringify(list.map(i => i.id))); } catch (e) { /* ignore */ }
  return list.length && Object.keys(w).length ? shelf('Recomendados para você', list, 'library') : '';
}
const V = () => $('#videoEl'), A = () => $('#audioPlayer');
let lastSave = 0, idleTimer, wakeV = () => {};
function watch(id, { resume = true, queue = null, pl } = {}) {
  const it = getItem(id); if (!it || it.type !== 'video') return;
  A().pause(); S.watchId = id; if (queue) { S.vqueue = queue; S.watchPl = pl !== undefined ? pl : (S.page === 'playlist' ? S.playlistId : S.watchPl); } else if (S.page !== 'playlist' && !S.vqueue.includes(id)) { S.vqueue = []; S.watchPl = null; }
  const v = V(), h = histOf(id), start = resume && h && h.progress > 5 && (!(it.duration || h.duration) || h.progress < (it.duration || h.duration) - 5) ? h.progress : 0;
  v.defaultPlaybackRate = cfg.vSpeed; v.src = urlFor(it); v.poster = it.cover || it.thumb || '';
  $('#vSpeed').value = String(cfg.vSpeed); $('#vFit').value = 'contain'; v.style.objectFit = 'contain'; $('#vMenu').hidden = true;
  setSubs(it.subs ? parseSubs(it.subs) : []);
  v.onloadedmetadata = () => { v.playbackRate = cfg.vSpeed; if (start) { v.currentTime = start; notify('Retomando de ' + fmtTime(start)); } if (!it.duration && Number.isFinite(v.duration)) { it.duration = v.duration; quiet(dbPut('items', it)); } updateVideoUI(); };
  v.onerror = () => { $('#vplayer').classList.remove('loading'); const c = v.error && v.error.code; notify(c === 3 || c === 4 ? 'Formato ou codec não compatível com este navegador. Tente converter para MP4 (H.264).' : c === 2 ? 'Falha de leitura do arquivo.' : 'Não foi possível reproduzir este vídeo.'); };
  $('#vQualRow').hidden = true; $('#vTopTitle').textContent = it.title; $('#vplayer').classList.add('loading');
  touchHistory(it, start ? undefined : 0);
  navigate('watch'); wakeV(); if (cfg.vAutoplay) v.play().catch(() => {});
  updateVideoUI();
}
function stopVideo() { const v = V(); resetPreview(); VS.cues = null; if (!v.getAttribute('src')) return; if (S.watchId) saveProgress(S.watchId, v.currentTime, v.duration); v.pause(); v.removeAttribute('src'); v.load(); document.body.classList.remove('cinema'); if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); }
function touchHistory(it, progress) {
  let h = histOf(it.id); if (h) S.history = S.history.filter(x => x !== h); else h = { id: it.id };
  h.date = Date.now(); h.type = it.type; h.duration = it.duration || h.duration || 0; if (progress !== undefined) h.progress = progress;
  S.history.unshift(h); quiet(dbPut('history', { ...h }));
}
function saveProgress(id, t, d) { const h = histOf(id); if (!h || !Number.isFinite(t) || t < 0) return; if (Number.isFinite(d) && d > 0 && t > d - 10) t = 0; h.progress = Math.floor(t); if (Number.isFinite(d) && d > 0) h.duration = d; quiet(dbPut('history', { ...h })); }
function updateVideoUI() {
  const v = V(), d = Number.isFinite(v.duration) ? v.duration : 0, t = v.currentTime || 0, pct = d ? Math.min(100, t / d * 100) : 0;
  $('#vPlay').innerHTML = ic(v.paused ? 'play' : 'pause'); $('#vPlay').setAttribute('aria-label', v.paused ? 'Reproduzir' : 'Pausar');
  $('#vBig').innerHTML = ic(v.paused ? 'play' : 'pause'); $('#vplayer').classList.toggle('paused', v.paused);
  $('#vTime').textContent = fmtTime(t) + (d ? ' / ' + fmtTime(d) : '');
  if (!VS.drag) { $('#vFill').style.width = pct + '%'; $('#vKnob').style.left = pct + '%'; }
  $('#vBar').setAttribute('aria-valuenow', Math.round(pct));
  try { if (v.buffered.length) $('#vBuf').style.width = (d ? v.buffered.end(v.buffered.length - 1) / d * 100 : 0) + '%'; } catch (e) { /* sem buffer */ }
  $('#vMute').innerHTML = ic(v.muted || v.volume === 0 ? 'mute' : 'volume');
}
const VS = { drag: false, subUrl: null };
/* Prévia em miniatura: um segundo <video> (mudo, sem áudio) busca o quadro e desenha no canvas; uma busca por vez */
const TP = { v: null, busy: false, next: null, src: '' };
function previewAt(t) {
  const main = V(), cv = $('#vThumb'), src = main.currentSrc || main.getAttribute('src'); if (!src || !Number.isFinite(main.duration) || matchMedia('(pointer:coarse)').matches) return;
  if (!TP.v) { TP.v = document.createElement('video'); TP.v.muted = true; TP.v.preload = 'auto'; TP.v.playsInline = true;
    TP.v.onseeked = () => { try { cv.getContext('2d').drawImage(TP.v, 0, 0, 160, 90); cv.hidden = false; } catch (e) { /* sem quadro */ } TP.busy = false; if (TP.next != null) { const n = TP.next; TP.next = null; previewAt(n); } };
    TP.v.onerror = () => { TP.busy = false; cv.hidden = true; }; }
  if (TP.src !== src) { TP.src = src; TP.v.src = src; cv.hidden = true; }
  if (TP.busy) { TP.next = t; return; } TP.busy = true; try { TP.v.currentTime = t; } catch (e) { TP.busy = false; }
}
function resetPreview() { if (TP.v) { TP.v.removeAttribute('src'); TP.v.load(); } TP.src = ''; TP.busy = false; TP.next = null; const c = $('#vThumb'); if (c) c.hidden = true; }
const clampT = (v, t) => Math.max(0, Number.isFinite(v.duration) ? Math.min(v.duration, t) : t);
function seekBy(d) { const v = V(); if (!v.getAttribute('src')) return; v.currentTime = clampT(v, v.currentTime + d); flashSeek(d); wakeV(); }
function flashSeek(d) { const f = $('#seekFlash'); f.textContent = (d < 0 ? '−' : '+') + Math.abs(d) + ' s'; f.className = 'seekflash ' + (d < 0 ? 'l' : 'r'); void f.offsetWidth; f.classList.add('go'); }
function setVolume(x) { const v = V(); v.volume = Math.max(0, Math.min(1, x)); v.muted = v.volume === 0; setP($('#vVol'), v.volume * 100); $('#vVol').value = v.volume; }
const fsEl = () => document.fullscreenElement || document.webkitFullscreenElement;
async function lockLandscape(on) { try { if (!screen.orientation || !screen.orientation.lock) return; if (on && matchMedia('(pointer:coarse)').matches) await screen.orientation.lock('landscape'); else if (!on) screen.orientation.unlock(); } catch (e) { /* não suportado */ } }
document.addEventListener('fullscreenchange', () => { lockLandscape(!!fsEl()); $('#vplayer').classList.toggle('fs', !!fsEl()); $('#vFull').innerHTML = ic(fsEl() ? 'close' : 'full'); });
function toggleFull() { const vv = V(); if (!fsEl() && !$('#vplayer').requestFullscreen && !$('#vplayer').webkitRequestFullscreen && vv.webkitEnterFullscreen) { vv.webkitEnterFullscreen(); return; } const p = $('#vplayer'); if (document.fullscreenElement || document.webkitFullscreenElement) (document.exitFullscreen || document.webkitExitFullscreen).call(document); else (p.requestFullscreen || p.webkitRequestFullscreen || (() => notify('Tela cheia indisponível neste navegador.'))).call(p); }
async function togglePip() { const v = V(); try { if (document.pictureInPictureElement) await document.exitPictureInPicture(); else if (document.pictureInPictureEnabled && !v.disablePictureInPicture) await v.requestPictureInPicture(); else notify('Picture-in-Picture não é compatível com este navegador.'); } catch (e) { notify('Não foi possível abrir o Picture-in-Picture.'); } }
/* Legendas: SRT/VTT convertidos para cues próprios (sem depender de <track>) */
function parseSubs(txt) {
  const cues = [], tm = x => { const m = x.trim().replace(',', '.').match(/(?:(\d+):)?(\d+):(\d+)\.(\d+)/); return m ? (+(m[1] || 0)) * 3600 + (+m[2]) * 60 + (+m[3]) + (+('0.' + m[4])) : NaN; };
  txt.replace(/\r/g, '').replace(/^\uFEFF/, '').split(/\n{2,}/).forEach(bl => {
    const ln = bl.split('\n'), i = ln.findIndex(l => l.includes('-->')); if (i < 0) return;
    const [x, y] = ln[i].split('-->'), st = tm(x), en = tm(y.trim().split(/\s+/)[0]); if (isNaN(st) || isNaN(en)) return;
    cues.push({ st, en, text: ln.slice(i + 1).join('\n').replace(/<[^>]+>/g, '') });
  });
  return cues;
}
function setSubs(cues) { VS.cues = cues; VS.on = !!cues.length; $('#subBox').textContent = ''; $('#vSubOff').hidden = !cues.length; $('#vCC').classList.toggle('on', VS.on); }
function renderSub() { if (!VS.on || !VS.cues) return; const t = V().currentTime, c = VS.cues.find(c => t >= c.st && t <= c.en), box = $('#subBox'), tx = c ? c.text : ''; if (box.textContent !== tx) box.textContent = tx; }
async function loadSubFile(f) {
  if (!f) return; if (f.size > 2e6) return notify('Arquivo de legenda grande demais.');
  const cues = parseSubs(await f.text()); if (!cues.length) return notify('Legenda inválida: use um arquivo .srt ou .vtt válido.');
  setSubs(cues); const it = getItem(S.watchId); if (it) { it.subs = await f.text(); quiet(dbPut('items', it)); } notify('Legenda carregada.');
}
function updateWatchInfo() {
  const it = getItem(S.watchId); if (!it) return;
  $('#watchTitle').textContent = it.title;
  $('#watchMeta').textContent = [it.category, fmtSize(it.size), it.duration ? fmtTime(it.duration) : '', 'Adicionado em ' + fmtDate(it.added), it.name].filter(Boolean).join(' · ');
  $('#watchDesc').textContent = it.description || 'Sem descrição.'; $('#watchDesc').hidden = false;
  const fav = inList(S.favorites, it.id), lat = inList(S.later, it.id), saved = lat || S.playlists.some(p => p.ids.includes(it.id));
  $('#watchActions').innerHTML = tbtn('fav', it.id, 'heart', fav ? 'Favorito' : 'Favoritar', fav) + tbtn('later', it.id, 'clock', lat ? 'Na lista' : 'Assistir mais tarde', lat) + tbtn('restart', it.id, 'prev', 'Reiniciar') + tbtn('addpl', it.id, 'list', saved ? 'Salvo' : 'Salvar', saved) + tbtn('dl', it.id, 'download', 'Baixar') + tbtn('del', it.id, 'trash', 'Excluir');
  renderPlPanel(it);
  const inPl = !!(S.watchPl && S.vqueue.length);
  const nextIds = inPl ? sortItems(S.items.filter(i => i.type === 'video' && i.id !== it.id), 'new').map(i => i.id) : S.vqueue.length ? S.vqueue.filter(i => i !== it.id) : sortItems(S.items.filter(i => i.type === 'video' && i.id !== it.id), 'new').map(i => i.id);
  $('#recs').innerHTML = nextIds.slice(0, 14).map(getItem).filter(Boolean).map(r => rowHTML(r, { cls: 'rec', sub: esc(r.artist || r.category) + ' · ' + fmtSize(r.size) })).join('') || '<p class="muted">Adicione mais vídeos para ver outras sugestões.</p>';
}
function renderPlPanel(it) {
  const el = $('#plPanel'); if (!el) return;
  const p = S.playlists.find(x => x.id === S.watchPl), q = S.vqueue.filter(id => getItem(id));
  if (!p || !q.includes(it.id)) { el.hidden = true; el.innerHTML = ''; return; }
  const i = q.indexOf(it.id), open = el.dataset.open === '1', nx = getItem(q[i + 1] || (S.vloop ? q[0] : ''));
  el.hidden = false;
  el.innerHTML = `<div class="plp-head" data-act="plpanel" tabindex="0" role="button" aria-expanded="${open}"><div class="plp-t"><strong>${esc(p.name)}</strong><small>${i + 1} / ${q.length}${nx ? ' · A seguir: ' + esc(nx.title) : ''}</small></div>${ibtn('plloop', '', 'repeat', 'Repetir playlist', S.vloop)}${ibtn('plshuf', '', 'shuffle', 'Embaralhar a seguir')}<span class="plp-chev">${ic(open ? 'up' : 'down')}</span></div>`
    + (open ? `<div class="plp-list">${q.map((id, n) => { const x = getItem(id); return `<div class="row plp-row${id === it.id ? ' cur' : ''}" tabindex="0" data-id="${id}" data-type="video"><span class="rnum">${id === it.id ? '▶' : n + 1}</span><div class="rthumb">${thumbHTML(x)}</div><div class="rinfo"><h3>${esc(x.title)}</h3><p>${esc(x.artist || x.category || '')}</p></div></div>`; }).join('')}</div>` : '');
  if (open) { const l = el.querySelector('.plp-list'), c = el.querySelector('.cur'); if (l && c) l.scrollTop = Math.max(0, c.offsetTop - l.offsetTop - 8); }
}
function toggleVideoPlay() { const v = V(); if (!v.getAttribute('src')) return; v.paused ? v.play().catch(() => {}) : v.pause(); }
function bindVideo() {
  const v = V(), pl = $('#vplayer'), bar = $('#vBar'), coarse = () => matchMedia('(pointer:coarse)').matches;
  v.onplay = () => { A().pause(); updateVideoUI(); wake(); }; v.onpause = () => { updateVideoUI(); wakeV(); if (S.watchId) saveProgress(S.watchId, v.currentTime, v.duration); };
  v.ontimeupdate = () => { updateVideoUI(); renderSub(); if (Date.now() - lastSave > 3000 && !v.paused) { lastSave = Date.now(); saveProgress(S.watchId, v.currentTime, v.duration); } };
  const flush = () => { if (S.page === 'watch' && S.watchId && v.getAttribute('src')) saveProgress(S.watchId, v.currentTime, v.duration); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); }); addEventListener('pagehide', flush);
  document.addEventListener('click', e => { if (!$('#vMenu').hidden && !e.target.closest('#vMenu,#vSet')) $('#vMenu').hidden = true; });
  v.onvolumechange = updateVideoUI; v.onprogress = updateVideoUI; v.onwaiting = v.onseeking = v.onloadstart = () => pl.classList.add('loading'); v.oncanplay = v.onplaying = v.onseeked = v.onloadeddata = () => pl.classList.remove('loading');
  v.onended = () => { saveProgress(S.watchId, 0, v.duration); updateVideoUI(); const q = S.vqueue, i = q.indexOf(S.watchId); if (i >= 0 && i < q.length - 1) watch(q[i + 1], { resume: false, queue: q, pl: S.watchPl }); else if (i >= 0 && S.vloop && q.length) watch(q[0], { resume: false, queue: q, pl: S.watchPl }); else notify('Reprodução concluída.'); };
  $('#vPlay').onclick = $('#vBig').onclick = e => { e.stopPropagation(); toggleVideoPlay(); };
  $('#vBack').onclick = () => seekBy(-10); $('#vFwd').onclick = () => seekBy(10);
  $('#vVol').oninput = e => setVolume(+e.target.value); $('#vMute').onclick = () => { v.muted = !v.muted; };
  $('#vSpeed').onchange = e => { v.playbackRate = +e.target.value; cfg.vSpeed = v.playbackRate; saveSettings(); };
  $('#vFit').onchange = e => { v.style.objectFit = e.target.value; };
  $('#vExit').onclick = e => { e.stopPropagation(); if (fsEl()) (document.exitFullscreen || document.webkitExitFullscreen).call(document); };
  $('#vCinema').onclick = () => document.body.classList.toggle('cinema'); $('#vFull').onclick = toggleFull; $('#vPip').onclick = togglePip;
  if (!document.pictureInPictureEnabled) $('#vPip').hidden = true;
  $('#vSet').onclick = e => { e.stopPropagation(); $('#vMenu').hidden = !$('#vMenu').hidden; };
  $('#vCC').onclick = () => { if (!VS.cues || !VS.cues.length) { $('#vSubInput').click(); return; } VS.on = !VS.on; $('#vCC').classList.toggle('on', VS.on); $('#subBox').textContent = ''; renderSub(); };
  $('#vSubLoad').onclick = () => $('#vSubInput').click(); $('#vSubOff').onclick = () => { setSubs([]); const it = getItem(S.watchId); if (it) { delete it.subs; quiet(dbPut('items', it)); } };
  $('#vSubInput').onchange = e => { loadSubFile(e.target.files[0]); e.target.value = ''; };
  /* Barra de progresso: clique, arraste (mouse/toque) e prévia do tempo */
  const posOf = e => { const r = bar.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); };
  const tip = e => { const p = posOf(e), t = $('#vTip'); $('b', t).textContent = fmtTime((v.duration || 0) * p); previewAt((v.duration || 0) * p); t.style.left = Math.max(24, Math.min(bar.clientWidth - 24, p * bar.clientWidth)) + 'px'; };
  const scrub = e => { const p = posOf(e); $('#vFill').style.width = p * 100 + '%'; $('#vKnob').style.left = p * 100 + '%'; tip(e); VS.pos = p; };
  bar.onpointerdown = e => { if (!Number.isFinite(v.duration) || !v.duration) { notify('Este vídeo não informa a duração; use ← → ou J/L para navegar.'); return; } VS.drag = true; bar.classList.add('drag'); bar.setPointerCapture(e.pointerId); scrub(e); wakeV(); };
  bar.onpointermove = e => { if (VS.drag) scrub(e); else tip(e); };
  bar.onpointerup = bar.onpointercancel = e => { if (!VS.drag) return; VS.drag = false; bar.classList.remove('drag'); v.currentTime = (v.duration || 0) * VS.pos; updateVideoUI(); };
  /* Controles: somem sozinhos durante a reprodução; ficam visíveis em pausa */
  function wake() { pl.classList.remove('idle'); clearTimeout(idleTimer); idleTimer = setTimeout(() => { if (!v.paused && !VS.drag && $('#vMenu').hidden) pl.classList.add('idle'); }, 3000); }
  wakeV = wake; pl.addEventListener('pointermove', e => { if (e.pointerType === 'mouse') wake(); }, { passive: true }); pl.addEventListener('keydown', wake); pl.addEventListener('focusin', wake);
  let lastTap = 0, tapT;
  v.onclick = e => {
    $('#vMenu').hidden = true;
    if (!coarse()) { toggleVideoPlay(); return; }
    const r = v.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, now = Date.now();
    if (now - lastTap < 320 && (x < .4 || x > .6)) { clearTimeout(tapT); lastTap = 0; seekBy(x < .5 ? -10 : 10); return; }
    lastTap = now; clearTimeout(tapT); tapT = setTimeout(() => { if (pl.classList.contains('idle') || v.paused) wake(); else pl.classList.add('idle'); }, 320);
  };
  matchMedia('(orientation:landscape)').addEventListener('change', e => {
    if (!coarse() || S.page !== 'watch') return;
    if (e.matches && !document.fullscreenElement) { const f = pl.requestFullscreen || pl.webkitRequestFullscreen; if (f) Promise.resolve(f.call(pl)).catch(() => {}); }
    else if (!e.matches && document.fullscreenElement) document.exitFullscreen().catch(() => {});
  });
  $('#watchDesc').onclick = e => e.currentTarget.classList.toggle('open');
}

/* ---------- 8. Música (player persistente) ---------- */
function playTrack(id, ids, { resume = false } = {}) {
  const it = getItem(id); if (!it) return;
  if (ids && ids.length) { S.queue = ids.filter(getItem); S.back = []; S.played = new Set(); }
  else if (!S.queue.includes(id)) { S.queue = S.items.filter(i => i.type === 'audio').map(i => i.id); S.back = []; S.played = new Set(); }
  S.qi = S.queue.indexOf(id); loadTrack(it, resume);
}
function loadTrack(it, resume) {
  const a = A(), v = V(); if (!v.paused) v.pause();
  const h = histOf(it.id), start = resume && h && h.progress > 5 ? h.progress : 0;
  S.curAudio = it.id; a.volume = cfg.mVolume; a.src = urlFor(it);
  a.addEventListener('loadedmetadata', () => { if (start) a.currentTime = start; if (!it.duration && Number.isFinite(a.duration)) { it.duration = a.duration; quiet(dbPut('items', it)); } updateBar(); }, { once: true });
  a.play().catch(() => notify('Toque em reproduzir para iniciar a música.'));
  touchHistory(it, start ? undefined : 0); updateBar(); if (S.page === 'history') render();
}
function nextTrack(auto) {
  const q = S.queue; if (!q.length) return; let i;
  if (S.shuffle && q.length > 1) {
    S.played.add(S.qi); let pool = q.map((_, k) => k).filter(k => !S.played.has(k));
    if (!pool.length) { if (S.repeat === 'all' || !auto) { S.played = new Set([S.qi]); pool = q.map((_, k) => k).filter(k => k !== S.qi); } else return endQueue(); }
    i = pool[Math.floor(Math.random() * pool.length)];
  } else { i = S.qi + 1; if (i >= q.length) { if (S.repeat === 'all' || !auto) i = 0; else return endQueue(); } }
  if (S.qi >= 0) S.back.push(S.qi); S.qi = i; loadTrack(getItem(q[i]));
}
function prevTrack() {
  const a = A(), q = S.queue; if (!q.length) return;
  if (a.currentTime > 3) { a.currentTime = 0; return; }
  if (S.back.length) S.qi = S.back.pop(); else if (S.qi > 0) S.qi--; else if (S.repeat === 'all') S.qi = q.length - 1; else { a.currentTime = 0; return; }
  loadTrack(getItem(q[S.qi]));
}
function endQueue() { const a = A(); a.pause(); a.currentTime = 0; if (S.curAudio) saveProgress(S.curAudio, 0, a.duration); updateBar(); }
function updateBar() {
  const a = A(), it = getItem(S.curAudio), paused = a.paused; document.body.classList.toggle('has-audio', !!it); if (!it) $('#playerbar').classList.remove('np');
  $('#nowTitle').textContent = it ? it.title : 'Nenhuma música selecionada'; $('#nowArtist').textContent = it ? (it.artist || it.category || 'VIEWTUBE') : 'Escolha uma faixa';
  $('#musicCover').innerHTML = it && it.cover ? `<img src="${it.cover}" alt="">` : ic('music');
  $('#playBtn').innerHTML = ic(paused ? 'play' : 'pause'); $('#playBtn').title = paused ? 'Reproduzir' : 'Pausar';
  $('#shuffleBtn').classList.toggle('on', S.shuffle); $('#shuffleBtn').title = 'Aleatório: ' + (S.shuffle ? 'ligado' : 'desligado');
  const rb = $('#repeatBtn'); rb.classList.toggle('on', S.repeat !== 'off'); rb.classList.toggle('one', S.repeat === 'one');
  rb.title = 'Repetição: ' + ({ off: 'desligada', all: 'playlist', one: 'música' }[S.repeat]);
  const nx = S.queue.length ? (S.shuffle ? 'A seguir: aleatório' : (S.queue[S.qi + 1] ? 'A seguir: ' + getItem(S.queue[S.qi + 1]).title : (S.repeat === 'all' ? 'A seguir: ' + getItem(S.queue[0]).title : ''))) : '';
  $('#nextUp').textContent = nx; $('#musicMute').innerHTML = ic(a.muted || a.volume === 0 ? 'mute' : 'volume');
  setP($('#musicVolume'), a.volume * 100);
}
let lastASave = 0;
function bindAudio() {
  const a = A();
  a.onplay = () => { const v = V(); if (!v.paused) v.pause(); updateBar(); }; a.onpause = () => { updateBar(); if (S.curAudio) saveProgress(S.curAudio, a.currentTime, a.duration); };
  a.ontimeupdate = () => { const pct = a.duration ? a.currentTime / a.duration * 1000 : 0; $('#musicProgress').value = pct; setP($('#musicProgress'), pct / 10); $('#miniProg').style.width = pct / 10 + '%';
    $('#currentTime').textContent = fmtTime(a.currentTime); $('#totalTime').textContent = fmtTime(a.duration);
    if (Date.now() - lastASave > 5000 && !a.paused && S.curAudio) { lastASave = Date.now(); saveProgress(S.curAudio, a.currentTime, a.duration); } };
  a.onended = () => { saveProgress(S.curAudio, 0, a.duration); if (S.repeat === 'one') { a.currentTime = 0; a.play(); } else if (cfg.mAutoplay) nextTrack(true); else endQueue(); };
  a.onerror = () => { if (a.getAttribute('src')) notify('Não foi possível reproduzir esta música.'); };
  $('#playBtn').onclick = () => { if (!a.getAttribute('src')) { const first = S.items.filter(i => i.type === 'audio'); if (first.length) playTrack(first[0].id, first.map(i => i.id)); else notify('Importe uma música para começar.'); return; } a.paused ? a.play().catch(() => {}) : a.pause(); };
  $('#nextBtn').onclick = () => S.queue.length ? nextTrack(false) : notify('Nenhuma música na fila.'); $('#prevBtn').onclick = () => S.queue.length ? prevTrack() : notify('Nenhuma música na fila.');
  $('#musicProgress').oninput = e => { if (a.duration) a.currentTime = a.duration * e.target.value / 1000; };
  $('#musicVolume').oninput = e => { a.volume = +e.target.value; a.muted = false; setP(e.target, a.volume * 100); updateBar(); };
  $('#musicVolume').onchange = e => { cfg.mVolume = +e.target.value; saveSettings(); };
  $('#musicMute').onclick = () => { a.muted = !a.muted; updateBar(); };
  $('#shuffleBtn').onclick = () => { S.shuffle = !S.shuffle; S.played = new Set(); cfg.mShuffle = S.shuffle; saveSettings(); updateBar(); };
  $('#repeatBtn').onclick = () => { S.repeat = { off: 'all', all: 'one', one: 'off' }[S.repeat]; cfg.mRepeat = S.repeat; saveSettings(); updateBar(); };
  a.volume = cfg.mVolume; $('#musicVolume').value = cfg.mVolume;
}

/* ---------- 9. Playlists ---------- */
let editingPl = null;
function openPlaylistModal(id) {
  editingPl = id || null; const p = S.playlists.find(x => x.id === id);
  $('#plModalTitle').textContent = p ? 'Editar playlist' : 'Criar playlist'; $('#playlistName').value = p ? p.name : ''; $('#playlistDescription').value = p ? p.description : '';
  openModal('playlistModal'); setTimeout(() => $('#playlistName').focus(), 50);
}
async function savePlaylist() {
  const name = $('#playlistName').value.trim(); if (!name) return notify('Informe um nome para a playlist.');
  if (S.playlists.some(p => p.id !== editingPl && p.name.toLowerCase() === name.toLowerCase())) return notify('Já existe uma playlist com esse nome.');
  try {
    let p = S.playlists.find(x => x.id === editingPl);
    if (p) { p.name = name; p.description = $('#playlistDescription').value.trim(); } else { p = { id: uid(), name, description: $('#playlistDescription').value.trim(), ids: [], created: Date.now() }; S.playlists.push(p); }
    await dbPut('playlists', p); closeModal('playlistModal'); render(); notify('Playlist salva!');
  } catch (e) { notify(errMsg(e)); }
}
async function updatePlaylist(p) { try { await dbPut('playlists', p); } catch (e) { notify(errMsg(e)); } render(); }
let pickCtx = null;
function openPick(mode, ref) {
  pickCtx = { mode, ref, creating: false }; $('#pickOk').hidden = mode !== 'items';
  const cb = $('#pickModal .modal-actions .btn[data-act=closepick]'); if (cb) cb.textContent = mode === 'playlist' ? 'Concluído' : 'Fechar';
  $('#pickModal').classList.toggle('ysheet', mode === 'playlist'); renderPick(); openModal('pickModal');
}
function renderPick() {
  const { mode, ref } = pickCtx, body = $('#pickBody');
  if (mode === 'playlist') {
    $('#pickTitle').textContent = 'Salvar em...';
    const row = (act, id, name, on, sub) => `<button type="button" class="pick ysave${on ? ' on' : ''}" role="checkbox" aria-checked="${on}" data-act="${act}" data-id="${id}"><span class="ysn"><b>${name}</b><small>${sub}</small></span><span class="ycheck" aria-hidden="true"></span></button>`;
    body.innerHTML = row('picklater', ref, 'Assistir mais tarde', inList(S.later, ref), 'Privada')
      + S.playlists.map(p => row('pickpl', p.id, esc(p.name), p.ids.includes(ref), p.ids.length + (p.ids.length === 1 ? ' item' : ' itens'))).join('')
      + (pickCtx.creating ? `<div class="ynew"><input id="pickNewName" maxlength="60" placeholder="Nome da playlist" aria-label="Nome da nova playlist" autocomplete="off"><button class="btn primary" data-act="picknew">Criar</button></div>`
        : `<button type="button" class="ynewbtn" data-act="picknewopen">${ic('plus')}<span>Nova playlist</span></button>`);
    const inp = $('#pickNewName'); if (inp) { inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); ACT.picknew(); } }; setTimeout(() => inp.focus(), 30); }
  } else {
    const p = S.playlists.find(x => x.id === ref); $('#pickTitle').textContent = 'Adicionar a “' + (p ? p.name : '') + '”';
    const avail = sortItems(S.items.filter(i => !p.ids.includes(i.id)), 'az');
    body.innerHTML = avail.length ? avail.map(i => `<label class="pick"><input type="checkbox" value="${i.id}">${ic(i.type === 'video' ? 'video' : 'music')}<span>${esc(i.title)}</span><small>${i.type === 'video' ? 'Vídeo' : 'Música'}</small></label>`).join('') : '<p class="muted">Todos os conteúdos da biblioteca já estão nesta playlist.</p>';
  }
}
function playPlaylist(id, shuffle = false) {
  const p = S.playlists.find(x => x.id === id); let items = p ? p.ids.map(getItem).filter(Boolean) : [];
  if (!items.length) return notify('Adicione conteúdos à playlist primeiro.');
  if (shuffle) { items = items.slice(); for (let k = items.length - 1; k > 0; k--) { const j = Math.floor(Math.random() * (k + 1)); [items[k], items[j]] = [items[j], items[k]]; } }
  const first = items[0];
  if (first.type === 'audio') playTrack(first.id, items.filter(i => i.type === 'audio').map(i => i.id)); else { S.playlistId = id; watch(first.id, { resume: false, pl: id, queue: items.filter(i => i.type === 'video').map(i => i.id) }); }
}

/* ---------- 10. Ações (favoritos, exclusão etc.) ---------- */
async function toggleList(store, id, onMsg, offMsg) {
  try { if (inList(S[store], id)) { await dbDel(store, id); S[store] = S[store].filter(x => x.id !== id); notify(offMsg); } else { const e = { id, date: Date.now() }; await dbPut(store, e); S[store].push(e); notify(onMsg); } }
  catch (e) { notify(errMsg(e)); } render();
}
async function deleteItem(id) {
  const it = getItem(id); if (!it || !confirm(`Excluir “${it.title}” da biblioteca? Esta ação não pode ser desfeita.`)) return;
  try {
    if (S.curAudio === id) { const a = A(); a.pause(); a.removeAttribute('src'); a.load(); S.curAudio = null; }
    S.queue = S.queue.filter(x => x !== id); S.qi = S.curAudio ? S.queue.indexOf(S.curAudio) : -1;
    await dbDel('items', id); for (const st of ['favorites', 'later', 'history']) { await dbDel(st, id); S[st] = S[st].filter(x => x.id !== id); }
    for (const p of S.playlists.filter(p => p.ids.includes(id))) { p.ids = p.ids.filter(x => x !== id); await dbPut('playlists', p); }
    S.items = S.items.filter(x => x.id !== id); revokeUrl(id); S.downloads = S.downloads.filter(x => x.id !== id); saveDownloadsLog();
    if (S.watchId === id) { S.watchId = null; stopVideo(); navigate('library'); notify('Conteúdo excluído.'); } else { render(); notify('Conteúdo excluído da biblioteca.'); }
    updateBar();
  } catch (e) { notify(errMsg(e)); }
}
async function wipeAll() {
  if (!confirm('Excluir TODOS os conteúdos, playlists, favoritos e histórico deste navegador?')) return;
  try { stopVideo(); const a = A(); a.pause(); a.removeAttribute('src'); a.load(); for (const n of STORES) await dbClear(n);
    S.items = []; S.playlists = []; S.history = []; S.later = []; S.favorites = []; S.downloads = []; S.queue = []; S.qi = -1; S.curAudio = null; S.watchId = null; saveDownloadsLog();
    [...urlCache.keys()].forEach(revokeUrl); updateBar(); render(); notify('Todos os dados locais foram removidos.'); } catch (e) { notify(errMsg(e)); }
}
function openItem(id, el) {
  const it = getItem(id); if (!it) return;
  if (it.type === 'video') { const ctx = el.closest('.list,.grid,.shelf'); const q = S.page === 'playlist' && ctx ? $$('[data-type=video][data-id]', ctx).map(n => n.dataset.id) : null; watch(id, { queue: q }); }
  else { const ctx = el.closest('.list,.grid,.shelf'); const ids = ctx ? $$('[data-type=audio][data-id]', ctx).map(n => n.dataset.id) : null; playTrack(id, ids); }
}
const ACT = {
  more: id => openSheet(id), upload: openUpload, closeupload: closeUpload, newpl: () => openPlaylistModal(), closepl: () => closeModal('playlistModal'), closepick: () => closeModal('pickModal'),
  fav: id => toggleList('favorites', id, 'Adicionado aos favoritos.', 'Removido dos favoritos.'),
  later: id => toggleList('later', id, 'Salvo em Assistir mais tarde.', 'Removido de Assistir mais tarde.'),
  addpl: id => openPick('playlist', id),
  del: deleteItem, dl: downloadItem,
  playall: () => { const l = viewList('music', 'audio'); if (l.length) playTrack(l[0].id, l.map(i => i.id)); else notify('Importe músicas primeiro.'); },
  clearhist: async () => { if (!confirm('Limpar todo o histórico?')) return; try { await dbClear('history'); S.history = []; render(); notify('Histórico limpo.'); } catch (e) { notify(errMsg(e)); } },
  rmhist: async id => { try { await dbDel('history', id); S.history = S.history.filter(h => h.id !== id); render(); } catch (e) { notify(errMsg(e)); } },
  resume: id => { const it = getItem(id); if (!it) return; if (it.type === 'video') watch(id, { resume: true }); else playTrack(id, null, { resume: true }); },
  plplay: id => playPlaylist(id), plshufplay: id => playPlaylist(id, true), pledit: id => openPlaylistModal(id), pladd: id => openPick('items', id),
  pldel: async id => { const p = S.playlists.find(x => x.id === id); if (!p || !confirm(`Excluir a playlist “${p.name}”? Os conteúdos continuam na biblioteca.`)) return; try { await dbDel('playlists', id); S.playlists = S.playlists.filter(x => x.id !== id); if (S.page === 'playlist') navigate('playlists'); else render(); notify('Playlist excluída.'); } catch (e) { notify(errMsg(e)); } },
  plrm: id => { const p = S.playlists.find(x => x.id === S.playlistId); p.ids = p.ids.filter(x => x !== id); updatePlaylist(p); },
  plup: id => movePl(id, -1), pldown: id => movePl(id, 1),
  pickpl: async id => { const p = S.playlists.find(x => x.id === id), item = pickCtx.ref; if (!p) return; const had = p.ids.includes(item); if (had) p.ids = p.ids.filter(x => x !== item); else p.ids.push(item); p.updated = Date.now(); await updatePlaylist(p); renderPick(); notify((had ? 'Removido de “' : 'Salvo em “') + p.name + '”'); },
  picklater: async id => { await toggleList('later', id, 'Salvo em Assistir mais tarde.', 'Removido de Assistir mais tarde.'); renderPick(); },
  picknewopen: () => { pickCtx.creating = true; renderPick(); },
  picknew: async () => { const inp = $('#pickNewName'), n = inp ? inp.value.trim() : ''; if (!n) return notify('Informe um nome para a playlist.'); if (S.playlists.some(p => p.name.toLowerCase() === n.toLowerCase())) return notify('Já existe uma playlist com esse nome.'); const p = { id: uid(), name: n, description: '', ids: [pickCtx.ref], created: Date.now(), updated: Date.now() }; S.playlists.push(p); await updatePlaylist(p); pickCtx.creating = false; renderPick(); notify('Salvo em “' + n + '”'); },
  plpanel: () => { const el = $('#plPanel'); el.dataset.open = el.dataset.open === '1' ? '0' : '1'; renderPlPanel(getItem(S.watchId)); },
  plloop: () => { S.vloop = !S.vloop; renderPlPanel(getItem(S.watchId)); notify(S.vloop ? 'Repetir playlist: ligado.' : 'Repetir playlist: desligado.'); },
  plshuf: () => { const q = S.vqueue, i = q.indexOf(S.watchId); if (i < 0) return; const rest = q.slice(i + 1); for (let k = rest.length - 1; k > 0; k--) { const j = Math.floor(Math.random() * (k + 1)); [rest[k], rest[j]] = [rest[j], rest[k]]; } S.vqueue = q.slice(0, i + 1).concat(rest); renderPlPanel(getItem(S.watchId)); notify('Próximos vídeos embaralhados.'); },
  pickok: () => { const p = S.playlists.find(x => x.id === pickCtx.ref), ids = $$('#pickBody input:checked').map(i => i.value); if (!ids.length) return notify('Selecione ao menos um conteúdo.'); p.ids.push(...ids); p.updated = Date.now(); updatePlaylist(p); closeModal('pickModal'); notify(ids.length + ' item(ns) adicionado(s).'); },
  sfilter: (id, el) => { S.search.type = el.dataset.v; rSearch(); }, ssort: (id, el) => { S.search.sort = el.dataset.v; rSearch(); },
  rmdl: id => { S.downloads = S.downloads.filter(x => x.id !== id); saveDownloadsLog(); rDownloads(); },
  cleardl: () => { S.downloads = []; saveDownloadsLog(); render(); notify('Lista de downloads limpa.'); },
  restart: () => { const v = V(); v.currentTime = 0; saveProgress(S.watchId, 0, v.duration); v.play().catch(() => {}); },
  wipe: wipeAll,
  exportall: () => exportBackup(true), exportmeta: () => exportBackup(false), importbk: () => $('#bkInput').click(),
  resetcfg: () => { if (!confirm('Restaurar as configurações padrão? Sua biblioteca não será afetada.')) return; cfg = { ...DEFAULTS }; saveSettings(); applyTheme(); applySettingsToUI(); notify('Configurações restauradas.'); }
};
/* ---------- Backup e restauração ---------- */
const blobToDataURL = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(b); });
async function exportBackup(full) {
  try {
    notify('Gerando backup...'); const out = { app: 'viewtube', version: 3, date: Date.now(), full, settings: cfg, playlists: S.playlists, favorites: S.favorites, later: S.later, history: S.history, items: [] };
    for (const it of S.items) { const { blob, ...meta } = it; if (full && blob) meta.file = await blobToDataURL(blob); out.items.push(meta); }
    const a = document.createElement('a'), u = URL.createObjectURL(new Blob([JSON.stringify(out)], { type: 'application/json' }));
    a.href = u; a.download = 'viewtube-backup-' + new Date().toISOString().slice(0, 10) + (full ? '' : '-dados') + '.json'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 4000);
    notify(full ? 'Backup completo exportado.' : 'Backup de dados exportado (sem os arquivos de mídia).');
  } catch (e) { notify('Falha ao exportar: ' + errMsg(e) + (full ? ' Tente “Exportar só dados”.' : '')); }
}
async function importBackup(f) {
  if (!f) return;
  try {
    const d = JSON.parse(await f.text()); if (d.app !== 'viewtube') throw new Error('Este arquivo não é um backup do ViewTube.');
    if (!confirm('Importar backup? Itens com o mesmo ID serão substituídos; o restante da biblioteca é mantido.')) return;
    let skipped = 0;
    for (const m of d.items || []) { const it = { ...m }; if (m.file) { it.blob = await (await fetch(m.file)).blob(); delete it.file; } else if (!S.items.some(x => x.id === m.id)) { skipped++; continue; } else continue; await dbPut('items', it); }
    for (const [st, key] of [['playlists', 'playlists'], ['favorites', 'favorites'], ['later', 'later'], ['history', 'history']]) for (const o of d[key] || []) await dbPut(st, o);
    if (d.settings) { cfg = { ...DEFAULTS, ...d.settings }; saveSettings(); }
    S.items = await dbAll('items'); S.playlists = await dbAll('playlists'); S.favorites = await dbAll('favorites'); S.later = await dbAll('later'); S.history = (await dbAll('history')).sort((a, b) => b.date - a.date);
    applyTheme(); applySettingsToUI(); render(); notify('Backup restaurado.' + (skipped ? ` ${skipped} item(ns) sem arquivo no backup foram ignorados.` : ''));
  } catch (e) { notify('Não foi possível importar: ' + errMsg(e)); }
}
/* ---------- Baixar por link (somente arquivos diretos de mídia, sujeito a CORS) ---------- */
async function downloadByLink() {
  const msg = t => { $('#linkMsg').textContent = t; }, prog = $('#linkProg'); let u;
  try { u = new URL($('#linkUrl').value.trim()); if (!/^https?:$/.test(u.protocol)) throw 0; } catch (e) { return msg('Endereço inválido. Cole um link que comece com http:// ou https://.'); }
  if (/(^|\.)(youtube\.com|youtu\.be|netflix\.com|spotify\.com|primevideo\.com|disneyplus\.com)$/i.test(u.hostname)) return msg('Este serviço não é compatível: o ViewTube só baixa arquivos diretos de mídia e não contorna restrições ou DRM.');
  $('#linkGo').disabled = true; msg('Verificando o link...'); prog.hidden = true;
  try {
    const res = await fetch(u.href, { mode: 'cors', credentials: 'omit' }); if (!res.ok) throw new Error('O servidor respondeu com erro ' + res.status + '.');
    let ct = (res.headers.get('content-type') || '').split(';')[0].toLowerCase(); const name = decodeURIComponent(u.pathname.split('/').pop() || 'arquivo'), ext = (name.split('.').pop() || '').toLowerCase();
    if (!/^(video|audio)\//.test(ct)) ct = EXT_MIME[ext] || ''; if (!ct) throw new Error('O link não aponta para um arquivo de vídeo ou áudio compatível.');
    const total = +res.headers.get('content-length') || 0, rd = res.body.getReader(), parts = []; let got = 0; prog.hidden = false; prog.value = 0;
    msg('Baixando' + (total ? ' (' + fmtSize(total) + ')' : '') + '...');
    for (;;) { const { done, value } = await rd.read(); if (done) break; parts.push(value); got += value.length; if (total) prog.value = got / total; }
    const file = new File(parts, name, { type: ct }), type = typeOf(file); if (!type) throw new Error('Formato não reconhecido.');
    const meta = await probeMedia(file, type).catch(() => ({})); await createItem(file, type, meta || {}, { title: name.replace(/\.[^.]+$/, ''), artist: '', category: 'Geral', description: 'Baixado por link: ' + u.hostname });
    msg('Concluído! Adicionado à sua biblioteca (' + fmtSize(got) + ').'); notify('Download concluído.');
  } catch (e) { msg(/Failed to fetch|NetworkError|Load failed/i.test(e.message || '') ? 'Não foi possível baixar: o servidor bloqueou o acesso de outros sites (CORS) ou o link está inacessível. Baixe o arquivo pelo navegador e use “Adicionar”.' : 'Não foi possível baixar: ' + errMsg(e)); }
  finally { $('#linkGo').disabled = false; }
}
function movePl(id, d) { const p = S.playlists.find(x => x.id === S.playlistId), i = p.ids.indexOf(id), j = i + d; if (j < 0 || j >= p.ids.length) return; [p.ids[i], p.ids[j]] = [p.ids[j], p.ids[i]]; updatePlaylist(p); }

/* ---------- 11. Pesquisa ---------- */
function rSearch() {
  const q = S.search.q.trim(), el = $('#searchArea'), s = S.search;
  const chip = (act, v, label, cur) => `<button class="chip ${cur === v ? 'active' : ''}" data-act="${act}" data-v="${v}">${label}</button>`;
  let html = `<h1 class="page-title">${q ? 'Resultados para “' + esc(q) + '”' : 'Pesquisar'}</h1><p class="sub">Vídeos, músicas, artistas, categorias e playlists.</p>
    <div class="chips">${chip('sfilter', 'all', 'Todos', s.type)}${chip('sfilter', 'video', 'Vídeos', s.type)}${chip('sfilter', 'audio', 'Músicas', s.type)}<span style="width:12px"></span>${chip('ssort', 'new', 'Mais recentes', s.sort)}${chip('ssort', 'old', 'Mais antigos', s.sort)}${chip('ssort', 'az', 'Ordem alfabética', s.sort)}</div>`;
  if (!q) { el.innerHTML = html + emptyHTML('Digite na barra de pesquisa acima para encontrar seus conteúdos.', false, 'O que você procura?'); return; }
  const items = sortItems(S.items.filter(i => (s.type === 'all' || i.type === s.type) && matches(i, q)), s.sort);
  const pls = s.type === 'all' ? S.playlists.filter(p => (p.name + ' ' + p.description).toLowerCase().includes(q.toLowerCase())) : [];
  if (!items.length && !pls.length) { el.innerHTML = html + `<div class="grid">${emptyHTML('Nenhum resultado encontrado para “' + esc(q) + '”. Tente outro termo ou ajuste os filtros.', false, 'Sem resultados')}</div>`; return; }
  el.innerHTML = html + (items.length ? `<div class="grid">${items.map(cardHTML).join('')}</div>` : '') + (pls.length ? group('Playlists', `<div class="grid">${pls.map(playlistCard).join('')}</div>`) : '');
}
let searchTimer;
function onSearchInput(immediate) { clearTimeout(searchTimer); const go = () => { S.search.q = $('#searchInput').value; if (S.page !== 'search') navigate('search'); else rSearch(); }; immediate ? go() : (searchTimer = setTimeout(go, 160)); }

/* ---------- 12. Downloads (somente arquivos importados pelo próprio usuário) ---------- */
function downloadItem(id) {
  const it = getItem(id); if (!it) return;
  const a = document.createElement('a'); a.href = urlFor(it); a.download = it.name || it.title; document.body.appendChild(a); a.click(); a.remove();
  S.downloads = S.downloads.filter(x => x.id !== id); S.downloads.unshift({ id, date: Date.now() }); saveDownloadsLog(); notify('Download iniciado: ' + (it.name || it.title)); if (S.page === 'downloads') rDownloads();
}
function rDownloads() {
  const log = S.downloads, el = $('#downloadArea'), fmt = it => (it.name.split('.').pop() || '').toUpperCase();
  const dlRows = log.map(d => { const it = getItem(d.id); return it ? rowHTML(it, { sub: `${it.type === 'video' ? 'Vídeo' : 'Música'} · ${fmt(it)} · ${fmtSize(it.size)}`, extra: `<p>${esc(it.name)} · baixado em ${fmtDateTime(d.date)}</p>`, actions: ibtn('dl', it.id, 'download', 'Baixar novamente') + ibtn('rmdl', it.id, 'close', 'Remover da lista'), cls: 'norow' }) : ''; }).join('');
  const avail = sortItems(S.items, 'new').map(it => rowHTML(it, { sub: `${it.type === 'video' ? 'Vídeo' : 'Música'} · ${fmt(it)} · ${fmtSize(it.size)}`, extra: `<p>${esc(it.name)}</p>`, actions: tbtn('dl', it.id, 'download', 'Baixar') })).join('');
  el.innerHTML = group('Lista de downloads', dlRows ? `<div class="list">${dlRows}</div>` : '<p class="muted">Nenhum download realizado ainda.</p>') + group('Disponíveis para baixar', avail ? `<div class="list">${avail}</div>` : emptyHTML('Importe conteúdos para poder baixá-los.', true));
}
async function refreshStorage() {
  const v = S.items.filter(i => i.type === 'video'), m = S.items.filter(i => i.type === 'audio'), total = S.items.reduce((a, b) => a + b.size, 0);
  let line = `${S.items.length} arquivo(s) armazenado(s): ${v.length} vídeo(s) e ${m.length} música(s) · ${fmtSize(total)} ocupados pela biblioteca.`;
  $('#storageInfo').textContent = line;
  try { if (navigator.storage && navigator.storage.estimate) { const e = await navigator.storage.estimate(); if (e.quota) $('#storageInfo').textContent = line + ` Uso total do site: ${fmtSize(e.usage)} de ${fmtSize(e.quota)} disponíveis.`; } } catch (e) { /* estimativa opcional */ }
}

/* ---------- 13. Interface: modais, eventos, configurações ---------- */
function openModal(id) { $('#' + id).classList.add('show'); }
function closeModal(id) { $('#' + id).classList.remove('show'); }
function applySettingsToUI() {
  $('#setTheme').value = cfg.theme; $('#setReduce').checked = cfg.reduceMotion; $('#setVAuto').checked = cfg.vAutoplay; $('#setSpeed').value = String(cfg.vSpeed);
  $('#setMAuto').checked = cfg.mAutoplay; $('#setMVol').value = cfg.mVolume; $('#setRepeat').value = cfg.mRepeat; $('#setShuffle').checked = cfg.mShuffle;
  $$('#setAccent button').forEach(b => b.classList.toggle('active', b.dataset.accent === cfg.accent));
  A().volume = cfg.mVolume; $('#musicVolume').value = cfg.mVolume; updateBar();
}
function setCfg(k, v) { cfg[k] = v; saveSettings(); applyTheme(); applySettingsToUI(); }
function bindSettings() {
  $('#setTheme').onchange = e => setCfg('theme', e.target.value); $('#themeBtn').onclick = () => setCfg('theme', cfg.theme === 'light' ? 'dark' : 'light');
  $('#setReduce').onchange = e => setCfg('reduceMotion', e.target.checked); $('#setVAuto').onchange = e => setCfg('vAutoplay', e.target.checked);
  $('#setSpeed').onchange = e => setCfg('vSpeed', +e.target.value); $('#setMAuto').onchange = e => setCfg('mAutoplay', e.target.checked);
  $('#setMVol').oninput = e => setCfg('mVolume', +e.target.value);
  $('#setRepeat').onchange = e => { S.repeat = e.target.value; setCfg('mRepeat', S.repeat); }; $('#setShuffle').onchange = e => { S.shuffle = e.target.checked; setCfg('mShuffle', S.shuffle); };
  $('#setAccent').onclick = e => { const b = e.target.closest('button[data-accent]'); if (b) setCfg('accent', b.dataset.accent); };
}
function bindUI() {
  if (uiBound) return; uiBound = true;
  $$('img.logo-img').forEach(img => img.addEventListener('error', () => { const f = document.createElement('div'); f.className = 'logo-fallback'; f.textContent = '▶'; img.replaceWith(f); }));
  document.addEventListener('click', e => {
    const act = e.target.closest('[data-act]');
    if (act) { e.preventDefault(); e.stopPropagation(); const fn = ACT[act.dataset.act]; if (fn) fn(act.dataset.id, act); if (act.closest('#sheet')) closeSheet(); return; }
    const sgb = e.target.closest('.sg'); if (sgb) { submitSearch(sgb.dataset.q); return; }
    const chb = e.target.closest('[data-chip]'); if (chb) { S.chip = chb.dataset.chip; R.home(); return; }
    if (e.target.id === 'sheetBack') { closeSheet(); return; }
    const go = e.target.closest('[data-goto]'); if (go) { e.preventDefault(); navigate(go.dataset.goto); return; }
    const pl = e.target.closest('[data-pl]'); if (pl) { S.playlistId = pl.dataset.pl; navigate('playlist'); return; }
    const item = e.target.closest('.card[data-id],.row[data-id],.sq[data-id]'); if (item) openItem(item.dataset.id, item);
    if (e.target.classList.contains('modal-back')) { if (e.target.id === 'uploadModal') closeUpload(); else e.target.classList.remove('show'); }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { const m = $('.modal-back.show'); if (m) { m.id === 'uploadModal' ? closeUpload() : m.classList.remove('show'); } return; }
    if ((e.key === 'Enter') && e.target.matches('.card,.row,.sq')) { e.preventDefault(); e.target.click(); return; }
    if (S.page !== 'watch' || e.ctrlKey || e.metaKey || e.altKey || e.target.closest('input,select,textarea,[contenteditable]')) return;
    if (e.target.closest('button') && (e.key === ' ' || e.key === 'Enter')) return;   // botão em foco usa a ação nativa dele
    if (!$('#vplayer').contains(e.target) && e.target.closest('button,a')) return;
    const v = V(), k = e.key.toLowerCase(); let used = true;
    if (k === ' ' || k === 'k') toggleVideoPlay(); else if (k === 'arrowleft') seekBy(-5); else if (k === 'arrowright') seekBy(5);
    else if (k === 'j') seekBy(-10); else if (k === 'l') seekBy(10); else if (k === 'f') toggleFull(); else if (k === 't') $('#vCinema').click();
    else if (k === 'm') v.muted = !v.muted; else if (k === 'arrowup') setVolume(v.volume + .05); else if (k === 'arrowdown') setVolume(v.volume - .05);
    else if (k === 'c') $('#vCC').click(); else if (k === 'p') togglePip(); else used = false;
    if (used) { e.preventDefault(); wakeV(); }
  });
  $('#nav').onclick = e => { const b = e.target.closest('button[data-page]'); if (b) navigate(b.dataset.page); };
  $('#menuBtn').onclick = () => { if (innerWidth > 900) { document.body.classList.toggle('side-collapsed'); try { localStorage.setItem('vt-side', document.body.classList.contains('side-collapsed') ? '1' : '0'); } catch (e) { /* ignore */ } } else document.body.classList.toggle('side-open'); };
  $('#backdrop').onclick = () => document.body.classList.remove('side-open');
  if (localStorage.getItem('vt-side') === '1') document.body.classList.add('side-collapsed');
  $('#linkGo').onclick = downloadByLink; $('#bkInput').onchange = e => { importBackup(e.target.files[0]); e.target.value = ''; };
  $('#uploadBtn').onclick = openUpload; $('#savePlaylist').onclick = savePlaylist; $('#saveUpload').onclick = saveUpload;
  $('#playlistName').onkeydown = e => { if (e.key === 'Enter') savePlaylist(); };
  $('#searchInput').oninput = () => onSearchInput(false); $('#searchBtn').onclick = () => onSearchInput(true); $('#searchInput').onkeydown = e => { if (e.key === 'Enter') onSearchInput(true); };
  $('#fileInput').onchange = e => onFilePicked(e.target.files[0]);
  $('#multiBtn').onclick = () => $('#multiInput').click(); $('#multiInput').onchange = e => importMany(e.target.files);
  if ('webkitdirectory' in $('#folderInput')) { $('#folderBtn').onclick = () => $('#folderInput').click(); $('#folderInput').onchange = e => importMany(e.target.files); } else $('#folderBtn').hidden = true;
  document.addEventListener('input', e => { const t = e.target; if (t.matches('.page-search')) { S.view[t.dataset.view].q = t.value.trim(); R[t.dataset.view === 'music' ? 'music' : t.dataset.view](); } });
  document.addEventListener('change', e => { const t = e.target; if (t.matches('.sort')) { S.view[t.dataset.view].sort = t.value; R[t.dataset.view](); } });
  $$('input[type=range]').forEach(r => { if (!r.id.startsWith('music') && r.id !== 'vProgress') setP(r, (r.value - r.min) / (r.max - r.min) * 100); });
  ['dragover','drop'].forEach(ev => addEventListener(ev, e => { if (!e.dataTransfer || ![...e.dataTransfer.types].includes('Files')) return; e.preventDefault(); if (ev === 'drop') importMany([...e.dataTransfer.files]); }));
  bindVideo(); bindAudio(); bindSettings();
  addEventListener('pagehide', () => { if (S.watchId && V().getAttribute('src')) saveProgress(S.watchId, V().currentTime, V().duration); if (S.curAudio) saveProgress(S.curAudio, A().currentTime, A().duration); });
  addEventListener('resize', () => { if (innerWidth > 900) document.body.classList.remove('side-open'); });
}

/* ---------- 13b. Folha de ações, pesquisa em tela cheia, Tocando agora, miniaturas ---------- */
function openSheet(id) {
  const it = getItem(id); if (!it) return; const fav = inList(S.favorites, id), lat = inList(S.later, id);
  const b = (act, icn, l) => `<button data-act="${act}" data-id="${id}">${ic(icn)}<span>${l}</span></button>`;
  $('#sheetTitle').textContent = it.title;
  $('#sheetBody').innerHTML = b('fav', 'heart', fav ? 'Remover dos favoritos' : 'Favoritar') + b('later', 'clock', lat ? 'Remover de Assistir mais tarde' : 'Assistir mais tarde') + b('addpl', 'list', 'Adicionar à playlist') + b('dl', 'download', 'Baixar') + b('del', 'trash', 'Excluir');
  $('#sheetBack').classList.add('show');
}
const closeSheet = () => $('#sheetBack').classList.remove('show');
const recents = () => { try { return JSON.parse(localStorage.getItem('vt-recent') || '[]') || []; } catch (e) { return []; } };
function submitSearch(q) {
  q = (q || '').trim(); if (!q) return;
  try { localStorage.setItem('vt-recent', JSON.stringify([q, ...recents().filter(x => x !== q)].slice(0, 8))); } catch (e) { /* ignore */ }
  S.search.q = q; $('#searchInput').value = q; $('#searchOverlay').classList.remove('show'); navigate('search');
}
function renderSuggest() {
  const q = $('#msInput').value.trim(), sg = (t, i) => `<button class="sg" data-q="${esc(t)}">${ic(i)}<span>${esc(t)}</span></button>`;
  let html;
  if (!q) html = recents().map(r => sg(r, 'history')).join('') + S.history.slice(0, 5).map(h => getItem(h.id)).filter(Boolean).map(i => sg(i.title, 'search')).join('');
  else html = S.items.filter(i => matches(i, q)).slice(0, 8).map(i => sg(i.title, 'search')).join('') || '<p class="muted" style="padding:16px">Nada encontrado na biblioteca.</p>';
  $('#msBody').innerHTML = html || '<p class="muted" style="padding:16px">Pesquise vídeos, músicas, artistas e playlists.</p>';
}
function bindExtras() {
  $('#searchOpen').onclick = () => { $('#msInput').value = S.search.q || ''; renderSuggest(); $('#searchOverlay').classList.add('show'); setTimeout(() => $('#msInput').focus(), 60); };
  $('#msBack').onclick = () => $('#searchOverlay').classList.remove('show');
  $('#msInput').oninput = renderSuggest; $('#msInput').onkeydown = e => { if (e.key === 'Enter') submitSearch($('#msInput').value); };
  $('#bottomnav').onclick = e => { const b = e.target.closest('button[data-page]'); if (b) navigate(b.dataset.page); };
  $('#pickBtn').onclick = () => $('#fileInput').click(); $('#coverBtn').onclick = () => $('#coverInput').click();
  $('#coverInput').onchange = e => { $('#coverName').textContent = e.target.files[0] ? e.target.files[0].name : 'Nenhuma'; };
  const pb = $('#playerbar'); let ty = 0;
  $('.track').onclick = () => { if (innerWidth <= 900 && S.curAudio) pb.classList.add('np'); };
  $('#npClose').onclick = e => { e.stopPropagation(); pb.classList.remove('np'); };
  pb.addEventListener('touchstart', e => { ty = e.touches[0].clientY; }, { passive: true });
  pb.addEventListener('touchend', e => { if (pb.classList.contains('np') && e.changedTouches[0].clientY - ty > 90 && !e.target.closest('input')) pb.classList.remove('np'); }, { passive: true });
  let ly = 0; addEventListener('scroll', () => { const y = scrollY; if (innerWidth <= 900) { if (y > ly + 6 && y > 80) document.body.classList.add('tb-hide'); else if (y < ly - 6 || y <= 80) document.body.classList.remove('tb-hide'); } ly = y; }, { passive: true });
  if (window.visualViewport) { const f = () => document.documentElement.style.setProperty('--vvh', visualViewport.height + 'px'); visualViewport.addEventListener('resize', f); f(); }
}
/* Miniaturas de vídeos sem capa: gera um quadro em segundo plano e guarda no IndexedDB */
let thumbBusy = false;
async function ensureThumbs() {
  if (thumbBusy) return; thumbBusy = true;
  for (const it of S.items.filter(i => i.type === 'video' && !i.thumb && !i.cover && !i.noThumb)) {
    try { const m = await probeMedia(it.blob, 'video'); if (m.thumb) { it.thumb = m.thumb; await dbPut('items', it); } else it.noThumb = true; } catch (e) { it.noThumb = true; }
    if (['home', 'videos', 'library', 'you'].includes(S.page)) render();
  }
  thumbBusy = false;
}

/* ---------- 14. Inicialização com tela de carregamento (progresso real por etapa) ---------- */
function setSplash(pct, text) { $('#splashBar').style.width = Math.round(pct * 100) + '%'; $('#splashStatus').textContent = text; $('.loadline').setAttribute('aria-valuenow', Math.round(pct * 100)); }
/* Arte da splash: se imagens/banner.png não carregar, entra o fundo roxo escuro com a logo */
function watchSplashArt() {
  const art = $('#splashArt'), fail = () => $('#splash').classList.add('no-banner');
  if (art.complete && art.naturalWidth === 0) fail(); // já falhou antes deste script rodar
  art.addEventListener('error', fail);
}
const waitImg = img => new Promise(res => { if (img.complete) return res(); img.addEventListener('load', res, { once: true }); img.addEventListener('error', res, { once: true }); });
const preloadLogo = () => new Promise(res => { const img = new Image(); img.onload = img.onerror = () => res(); img.src = 'imagens/logo.png'; });
const preloadAssets = () => Promise.race([Promise.all([waitImg($('#splashArt')), preloadLogo()]), sleep(4000)]);
watchSplashArt();
async function init() {
  const splashStartedAt = Date.now();
  $('#splashError').hidden = true;
  const steps = [
    ['Carregando recursos', preloadAssets],
    ['Recuperando configurações', async () => { loadSettings(); loadDownloadsLog(); }],
    ['Inicializando o armazenamento', openDB],
    ['Recuperando a biblioteca de vídeos e músicas', async () => { S.items = await dbAll('items'); }],
    ['Carregando playlists e favoritos', async () => { [S.playlists, S.favorites, S.later] = await Promise.all([dbAll('playlists'), dbAll('favorites'), dbAll('later')]); S.playlists.forEach(p => { p.ids = p.ids || []; }); }],
    ['Recuperando o histórico', async () => { S.history = (await dbAll('history')).sort((a, b) => b.date - a.date); }],
    ['Preparando a interface', async () => { bindUI(); bindExtras(); applySettingsToUI(); navigate('home'); }]
  ];
  for (let i = 0; i < steps.length; i++) {
    setSplash(i / steps.length, steps[i][0] + '...');
    try { await steps[i][1](); }
    catch (e) { console.error('VIEWTUBE:', e); $('#splashErrorMsg').textContent = 'Não foi possível iniciar: ' + errMsg(e); $('#splashError').hidden = false; setSplash(i / steps.length, 'Erro na etapa: ' + steps[i][0]); return; }
  }
  // Mantém a tela de abertura visível por pelo menos 5 segundos,
  // mesmo quando o armazenamento e os recursos carregam muito rápido.
  const minimumSplashTime = 5000;
  const elapsedSplashTime = Date.now() - splashStartedAt;
  if (elapsedSplashTime < minimumSplashTime) {
    setSplash(0.96, 'Finalizando sua experiência...');
    await sleep(minimumSplashTime - elapsedSplashTime);
  }
  setSplash(1, 'Tudo pronto!');
  await sleep(650);
  $('#splash').classList.add('hide');
  ensureThumbs();
}
$('#splashRetry').onclick = init;
init();

/* ---------- 15. PWA: instalação, offline e atualização ---------- */
/* A instalação só funciona via https:// ou http://localhost. Em file:// o app abre normalmente, só não instala. */
const PWA = { deferred: null, reg: null, wantReload: false };
const isLocalHost = ['localhost', '127.0.0.1', '[::1]', '::1'].includes(location.hostname);
const pwaContextOK = () => location.protocol === 'https:' || (location.protocol === 'http:' && isLocalHost);
const isStandalone = () => matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: fullscreen)').matches || navigator.standalone === true;
const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

function updatePwaUI() {
  const canInstall = !!PWA.deferred && !isStandalone();
  ['#installBtn', '#setInstallBtn'].forEach(sel => { const b = $(sel); if (b) b.hidden = !canInstall; });
  const status = $('#pwaStatus'), help = $('#pwaHelp'); if (!status || !help) return;
  let msg, tip = '';
  if (isStandalone()) msg = 'O ViewTube já está instalado e aberto como aplicativo.';
  else if (canInstall) msg = 'Instale o ViewTube para abri-lo em uma janela própria, com ícone, e usá-lo mesmo sem internet.';
  else if (isIOS()) { msg = 'Neste aparelho a instalação é feita pelo navegador.'; tip = 'Toque em Compartilhar > Adicionar à Tela de Início.'; }
  else if (!pwaContextOK()) { msg = 'A instalação não está disponível nesta forma de abertura.'; tip = 'Abra o ViewTube por https:// ou http://localhost (veja o LEIA-ME).'; }
  else { msg = 'Se o seu navegador permitir, a opção de instalar aparecerá aqui ou na barra de endereço.'; tip = 'No Chrome: menu ⋮ > Instalar ViewTube. Se já instalou, abra pelo ícone do aplicativo.'; }
  status.textContent = msg; help.textContent = tip; help.hidden = !tip;
  const cu = $('#checkUpdateBtn'); if (cu) cu.hidden = !PWA.reg;
}

async function installApp() {
  const ev = PWA.deferred; if (!ev) return;
  PWA.deferred = null; updatePwaUI();   // o evento só pode ser usado uma vez
  try {
    ev.prompt();
    const choice = await ev.userChoice;
    if (choice && choice.outcome === 'dismissed') notify('Tudo bem! Você pode instalar depois em Configurações > Aplicativo.');
  } catch (e) { console.warn('VIEWTUBE: instalação não concluída', e); }
}

function showUpdateBar(worker) {
  const bar = $('#updateBar'); if (!bar || !worker) return;
  bar.hidden = false;
  $('#updateBtn').onclick = () => { PWA.wantReload = true; bar.hidden = true; notify('Atualizando o ViewTube...'); worker.postMessage({ type: 'SKIP_WAITING' }); };
  $('#updateLater').onclick = () => { bar.hidden = true; };
}

async function registerSW() {
  if (!('serviceWorker' in navigator) || !pwaContextOK()) return;   // file:// e http comum: não registra, sem erro
  try {
    const hadController = !!navigator.serviceWorker.controller;
    const reg = await navigator.serviceWorker.register('sw.js', { scope: './', updateViaCache: 'none' });
    PWA.reg = reg; updatePwaUI();
    if (reg.waiting && navigator.serviceWorker.controller) showUpdateBar(reg.waiting);
    reg.addEventListener('updatefound', () => {
      const nw = reg.installing; if (!nw) return;
      nw.addEventListener('statechange', () => {
        if (nw.state !== 'installed') return;
        if (navigator.serviceWorker.controller) showUpdateBar(nw);               // havia versão antiga: pergunta ao usuário
        else if (!hadController) notify('Pronto! O ViewTube agora também funciona offline.'); // primeira instalação
      });
    });
    // Troca de versão concluída: recarrega só se o usuário clicou em "Atualizar"
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (PWA.wantReload) location.reload(); });
    // Procura versão nova ao abrir, ao voltar para a aba e de hora em hora
    const check = () => reg.update().catch(() => { /* offline */ });
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') check(); });
    setInterval(check, 60 * 60 * 1000);
  } catch (e) { console.warn('VIEWTUBE: service worker indisponível', e); }
}

function initPWA() {
  addEventListener('beforeinstallprompt', e => { e.preventDefault(); PWA.deferred = e; updatePwaUI(); });
  addEventListener('appinstalled', () => { PWA.deferred = null; updatePwaUI(); notify('ViewTube instalado com sucesso! Procure o ícone no seu aparelho.'); });
  try { matchMedia('(display-mode: standalone)').addEventListener('change', updatePwaUI); } catch (e) { /* Safari antigo */ }
  $('#installBtn').onclick = installApp; $('#setInstallBtn').onclick = installApp;
  $('#checkUpdateBtn').onclick = async () => {
    if (!PWA.reg) return;
    try { await PWA.reg.update(); if (PWA.reg.waiting) showUpdateBar(PWA.reg.waiting); else if (!PWA.reg.installing) notify('Você já está com a versão mais recente.'); }
    catch (e) { notify('Não foi possível verificar agora. Confira sua conexão.'); }
  };
  updatePwaUI();
  registerSW();
}
initPWA();
